import {inject} from '@angular/core';
import {CanActivateFn, Router} from '@angular/router';
import {GlobalMessage} from '../../../globals/global.message';
import {SessionService} from '../../../globals/sessionstorage';
import {Sessiondata} from "../../../models/Sessiondata";
import {Global_CurrentFinYear} from "../../../globals/global-variable";
import {CommonService} from "../../../globals/common.service";
import * as myGlobals from "../../../globals/global-variable";

interface outputtype {
    sucess: boolean,
    type: string,
}
export const marksheetviewGuard: CanActivateFn = (route, state) => {
    const sessionservice = inject(SessionService);
    const router = inject(Router);
    const globalmessage = inject(GlobalMessage);
    const oSession = new Sessiondata(sessionservice);
    oSession.Getdatafromstroage();

    if (!isEligibleForPage( oSession, globalmessage)) {
        router.navigate(['/dashboard']);
        return false;
    }
    return true;
};

// ------------------ Helper functions below ------------------ //
function isEligibleForPage(
    oSession: Sessiondata,
    globalmessage: GlobalMessage
): boolean {

    if (oSession.lastyearoutstanding == 'true') {
        globalmessage.Show_message('Please pay your last year pending fees.Select the Fees Payment option.!')
        return false;
    }

    return true
}



