import {HttpClientModule} from '@angular/common/http';
import {NgModule} from '@angular/core';
import {FormsModule} from '@angular/forms';
import {JrstudentprofileRoutingModule} from './jrstudentprofile-routing.module';
import {AccordionModule, CalloutModule} from "@coreui/angular-pro";

// import { SelectModule } from 'ng-select';


@NgModule({
  imports: [
    JrstudentprofileRoutingModule,
    HttpClientModule,
    FormsModule,
    AccordionModule,
    CalloutModule
  ],
  // exports: [FillprofileComponent],
  declarations: []
})
export class JrstudentprofileModule { }
