import {Component, OnInit, Renderer2} from '@angular/core';
import {FormArray, FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators} from "@angular/forms";
import {
    BorderDirective, ButtonDirective,
    CardBodyComponent,
    CardComponent,
    ColComponent,
    FormCheckInputDirective,
    FormCheckLabelDirective, FormLabelDirective, FormSelectDirective,
    ListGroupItemDirective,
    RowComponent,
    TableDirective
} from "@coreui/angular-pro";
import { JsonPipe, KeyValuePipe } from "@angular/common";
import {Sessiondata} from "../../../models/Sessiondata";
import {SessionService} from "../../../globals/sessionstorage";
import {encryptUsingAES256} from "../../../globals/encryptdata";
import {Common_url, Fees_url, Students_url} from "../../../globals/global-api";
import Swal from "sweetalert2";
import {CommonService} from "../../../globals/common.service";
import {DynamiccheckboxService} from "./dynamiccheckbox.service";
import {
    Ires_PhdBatchs,
    Ires_Reciept,
    Ires_subjectlist,
    Ires_subjects,
    res_singlebatch,
    Send_jsonstudentsubject
} from "../../../models/response";
import {AutocompleteLibModule} from "angular-ng-autocomplete";
import {IBatchs} from "../../../models/request";
import {filter} from "rxjs/operators";
import {NgxSearchFilterModule} from "ngx-search-filter";
import {GlobalMessage} from "../../../globals/global.message";
import * as myGlobals from "../../../globals/global-variable";
import {BilldeskPay} from "../../../../assets/javascript/billdesk";
import {Router} from "@angular/router";
import {Global_CurrentFinYear} from "../../../globals/global-variable";

@Component({
    selector: 'app-dynamicchekbox',
    imports: [
        ReactiveFormsModule,
        ListGroupItemDirective,
        KeyValuePipe,
        FormCheckInputDirective,
        FormCheckLabelDirective,
        ColComponent,
        AutocompleteLibModule,
        RowComponent,
        CardBodyComponent,
        CardComponent,
        TableDirective,
        NgxSearchFilterModule,
        BorderDirective,
        FormsModule,
        ButtonDirective,
        FormSelectDirective,
        FormLabelDirective
    ],
    standalone: true,
    templateUrl: './dynamicchekbox.component.html',
    styleUrl: './dynamicchekbox.component.scss'
})
export class DynamicchekboxComponent implements OnInit {
    form!: FormGroup;
    Batchs!: IBatchs[];
    Batchkeyword = 'Batch_Name';
    BatchCode: number = 0;
    Subjects!: Ires_subjects[]
    Selected_subjects!: Ires_subjects
    groupedData: any = {};
    subject_group_list: Ires_subjectlist[] = []
    oSession!: Sessiondata;
    selected_subject!: Ires_subjectlist
    arraypush: Ires_subjectlist[] = []
    table_one: Ires_subjectlist[] = [];
    table_two: Ires_subjectlist[] = [];
    Viewtable = false
    incremental_batch: any
    resp_singlebatch: res_singlebatch = {} as res_singlebatch;
    // majorsubject: Subjects_group_h = {} as Subjects_group_h;
    majorsubject: Ires_subjects[] = [];
    res_Reciept = {} as Ires_Reciept
    portal = {} as Ires_PhdBatchs;
    billdeskRequestMsg: string = '';
    submit_diabl = true
    show_selected_table = false
    subjectlist = true
    table_one_selected: Ires_subjectlist[] = [];
    table_two_selected: Ires_subjectlist[] = [];

    constructor(private fb: FormBuilder, private router: Router,
                private globalmessage: GlobalMessage,
                private commonService: CommonService, private renderer: Renderer2,
                private dynamicService: DynamiccheckboxService,
                private sessionservice: SessionService) {
    }

    ngOnInit(): void {
        // this.globalmessage.Show_message('Admission not started!')
        // this.router.navigate(['dashboard']);
        this.oSession = new Sessiondata(this.sessionservice);
        this.oSession.Getdatafromstroage();
        this.form = this.fb.group({
            selectedItems: this.fb.array([]),
            // Subject_Name: ['', Validators.required],
            selection_checked: ['']
        });
        if (this.oSession.formfeesrecieved == 'PAID') {
            this.show_selected_table = true
            this.subjectlist = false
            this.student_selectedsubjectthird()
            // alert('PAID')
        }
        this.renderExternalScript(
            'https://pgi.billdesk.com/payments-checkout-widget/src/app.bundle.js'
        ).onload = () => {
        };
        // this.groupItems();
        // this.GetBatchApi();
        this.single_batch()
    }

    renderExternalScript(src: string): HTMLScriptElement {
        const script = document.createElement('script');
        script.type = 'text/javascript';
        script.src = src;
        script.async = true;
        script.defer = true;
        this.renderer.appendChild(document.body, script);
        return script;
    }

    GetBatchApi() {
        //Batch select list displaying
        this.commonService.getBatches().subscribe((response: any) => {
            if (response['data'] == '' || response['data'] == null) {
                // this.dialogService.open({ message: 'No data found! Please Configure Marksheet..', positive: 'Ok', })//alert
                Swal.fire({
                    title: 'Error!',
                    text: 'No data found! Please Configure Marksheet..',
                    icon: 'error',
                    confirmButtonText: 'OK',
                }); //alert
            } else {
                this.Batchs = response['data'];
            }
        });
    }

    single_batch() {
        let jsonin = {
            Batchcode: this.oSession.maxbatchcode,
        };
        let input_json = {
            Input: encryptUsingAES256(jsonin),
        };
        this.commonService.Post_json_data(Common_url.batch, input_json).subscribe((response) => {
            this.incremental_batch = response.data
            this.single_subject()
            if (this.incremental_batch.Batch_level >= 1 &&
                this.incremental_batch.Admissionboard == 'UG') {
                if (this.oSession.maxfinyear! < myGlobals.Global_CurrentFinYear) {
                    //FYBCom to SYBCom
                    this.Incremental_batch(this.incremental_batch.Next_batch)
                }
            }
        })
    }

    single_subject() {
        let batch_code = 0
        if (this.incremental_batch.Next_batch == 11103 || this.incremental_batch.Next_batch == 10603) {
            batch_code = this.incremental_batch.Next_batch
        } else {
            batch_code = this.incremental_batch.Batch_code
        }
        let jsonin = {
            Batch_code: batch_code,
            Subject_group_code: this.oSession.maxsubjectgroupcode,
            Subject_group_id: this.oSession.maxsubjectgroupid,
        }
        //Changes made by Shivam
        let jsonin_input = {
            Input: encryptUsingAES256(jsonin),
        };
        if (this.incremental_batch.Next_batch == 11103 || this.incremental_batch.Next_batch == 10603) {
            this.commonService
                .Post_json_data<Ires_subjects[]>(Fees_url.bms_subject, jsonin_input)
                .subscribe((response) => {
                    this.majorsubject = response.data
                });
            return
        }

        this.majorsubject = []
        this.commonService
            .Post_json_data<Ires_subjects>(Fees_url.single_subject, jsonin_input)
            .subscribe((response) => {
                // this.majorsubject = response.data
                let singlesubject_array = response.data
                this.majorsubject.push(singlesubject_array)
            });

    }

    Incremental_batch(nIncbatch: number) {
        let jsonin = {
            Batchcode: nIncbatch,
        };
        let input_json = {
            Input: encryptUsingAES256(jsonin),
        };
        this.commonService
            .Post_json_data<res_singlebatch>(Common_url.batch, input_json)
            .subscribe((response) => {
                this.resp_singlebatch = response.data;
                this.subject_list()
                // this.PortalOpen()
            });
    }

    selectBatch(bat: any) {
        this.BatchCode = bat.Batch_Code;
        this.subject_list()
    }

    subjectgroup_d_list() {
        this.subject_group_list = []
        this.arraypush = []
        this.groupedData = {}
        let jsonin = {
            finyear: this.oSession.finyear,
            college_code: this.oSession.collegecode,
            aadhaar: this.oSession.aadhaar,
            batch_code: this.resp_singlebatch.Batch_code,
            subject_group_code: this.Selected_subjects.Subject_group_code
        };
        let input_jsonin = {
            Input: encryptUsingAES256(jsonin),
        };
        this.dynamicService
            .subjectgroup_d_list(Fees_url.subjectgroup_d_list, input_jsonin)
            .subscribe((response) => {
                this.subject_group_list = response
                if (this.subject_group_list == null) {
                    return
                }
                this.Viewtable = true
                this.subject_group_list.forEach(item => {
                    if (!this.groupedData[item.Semester]) {
                        this.groupedData[item.Semester] = {};
                    }
                    if (!this.groupedData[item.Semester][item.Verticalname]) {
                        this.groupedData[item.Semester][item.Verticalname] = [];
                    }
                    //
                    this.groupedData[item.Semester][item.Verticalname].push(item);
                    if (item.Mandatory === 1) {
                        const selected = this.form.get('selectedItems') as FormArray;
                        const uniqueKey = `${item.Semester}_${item.Verticalname}_${item.Subject_detail_id}`;
                        if (!selected.value.includes(uniqueKey)) {
                            selected.push(this.fb.control(uniqueKey));
                            this.arraypush.push(item);
                        }
                    }
                });
            });
    }

    filreddata() {
        this.table_one = this.arraypush.filter((item) => item.Semester === 5);
        this.table_two = this.arraypush.filter((item) => item.Semester === 6);
    }

    subject_list() {
        let jsonin = {
            Finyear: this.oSession.finyear,
            College_code: this.oSession.collegecode,
            Aadhaar: this.oSession.aadhaar,
            Batch_code: this.resp_singlebatch.Batch_code,
        };
        let input_jsonin = {
            Input: encryptUsingAES256(jsonin),
        };
        this.dynamicService
            .subject_list(Fees_url.subjectgroup_list, input_jsonin)
            .subscribe((response) => {
                this.Subjects = response.data
            })
    }

    onCheckboxChange(e: any, item: Ires_subjectlist): void {
        if (item == null) {
            return;
        }

        let selected = this.form.get('selectedItems') as FormArray;
        let uniqueKey = `${item.Semester}_${item.Verticalname}_${item.Subject_detail_id}`;
        let selectedItemsInCategory = selected.controls
            .map(control => control.value)
            .filter((val: string) =>
                val?.startsWith(`${item.Semester}_${item.Verticalname}_`)
            );
        let mandatory = this.subject_group_list.filter((man_object: Ires_subjectlist) =>
            man_object.Semester === item.Semester &&
            man_object.Subjectcatid === item.Subjectcatid &&
            man_object.Mandatory === 1);
        if (e.target.checked) {
            if (selectedItemsInCategory.length - mandatory.length < item.Noofoptionalsubject) {
                selected.push(this.fb.control(uniqueKey));
                this.arraypush.push(item)
            } else {
                e.target.checked = false;
                this.globalmessage.Show_error(`You can only select up to ${item.Noofoptionalsubject} item(s) in category "${item.Verticalname}" of semester ${item.Semester}`)
                return
            }
        } else {
            const index = selected.controls.findIndex(control => control.value === uniqueKey);
            if (index !== -1) {
                this.arraypush = this.arraypush.filter(array_item => array_item.Subject_detail_id !== item.Subject_detail_id);
                selected.removeAt(index);
            }
        }
        /*
        this.arraypush = this.arraypush.filter(
          (subject) =>
            !(
              subject.Semester === item.Semester &&
              subject.Categoryname === item.Categoryname &&
              subject.Subject_detail_id === item.Subject_detail_id
            )
        );
        */
        this.filreddata()
    }

    submit(): void {
        let table_one = this.arraypush.filter((item) => item.Semester === 5);
        let table_two = this.arraypush.filter((item) => item.Semester === 6);
        let check_json: any = {};
        let check_json_tabletwo: any = {};
        check_json = table_one.filter((item) => item.Mandatory === 0)
        check_json_tabletwo = table_two.filter((item) => item.Mandatory === 0)
        // for (const single_object of table_one.filter((item) => item.Mandatory === 0)) {
        //     check_json = single_object;
        //     break;
        // }
        // for (const single_obj of table_two.filter((item) => item.Mandatory === 0)) {
        //     check_json_tabletwo = single_obj;
        //     break;
        // }
        const isCheckJson_tableone = Object.keys(check_json).length > 0;
        const isCheckJson_tabletwo = Object.keys(check_json_tabletwo).length > 0;
        if (isCheckJson_tableone && isCheckJson_tabletwo) {
            for (const inputJsoninElement of this.arraypush) {
                inputJsoninElement.Finyear = this.oSession.finyear
                inputJsoninElement.College_code = this.oSession.collegecode
                inputJsoninElement.Aadhaar = this.oSession.aadhaar
            }
            let jsonin: Send_jsonstudentsubject = {} as Send_jsonstudentsubject
            /*let jsonin = {
              // Inputjsonarray: this.arraypush

            }*/
            jsonin.Aadhaar = this.oSession.aadhaar!
            jsonin.Finyear = this.oSession.finyear!
            jsonin.Batch_code = this.resp_singlebatch.Batch_code
            jsonin.College_code = this.oSession.collegecode!
            jsonin.Prefix_code = 9999
            jsonin.Subject_group_Code = this.Selected_subjects.Subject_group_code
            jsonin.Subject_group_ID = this.Selected_subjects.Subject_group_id
            jsonin.Applicationmode = 'THIRDYEAR'
            jsonin.Term_code = 9999
            jsonin.Inputjsonarray = this.arraypush
            let input_jsonin = {
                Input: encryptUsingAES256(jsonin),
            };
            this.dynamicService
                .savestudentsubjects(Students_url.savestudentsubjects, input_jsonin)
                .subscribe((response) => {
                    this.res_Reciept = response.data
                    if (this.res_Reciept.ReceiptID > 0) {
                        this.RegistrationPayment();
                    }
                    // this.Subjects = response.data
                    // this.globalmessage.Show_successmessage('Data saved successfully.')
                })
        } else {
            this.globalmessage.Show_error('Please select from both the semesters');
            return;
        }
        // let check_json = {}
        // let check_json_tabletwo = {}
        //
        // for (const single_object of table_one.filter((item) => item.Mandatory === 0)) {
        //     check_json = single_object;
        //     // return;
        // }
        //
        // for (const single_obj of table_two.filter((item) => item.Mandatory === 0)) {
        //     check_json_tabletwo = single_obj;
        //     // return;
        // }
        //
        //
        // if (
        //     Object.keys(check_json).length === 0 &&
        //     Object.keys(check_json_tabletwo).length === 0
        // ) {
        //     this.globalmessage.Show_error('Please select something') // User hasn't selected anything
        //     return;
        // } else {
        //     this.globalmessage.Show_error('Selection is partially complete or invalid');
        // }
        // if(check_json != null && check_json_tabletwo != null) {
        //     this.globalmessage.Show_error('Please selecccyuiii')
        //     return
        // }else{
        //     this.globalmessage.Show_error('selecccyuiii errracvfdd')
        // }
        // for (const single_object of table_two) {
        // return
        // }
    }

    RegistrationPayment() {
        let nTranscationamount = '';
        let jsonin = {
            collegecode: myGlobals.Golbal_CollegeCode,
            finyear: this.oSession.finyear,
            batchcode: this.resp_singlebatch.Batch_code,
            aadhaar: this.oSession.aadhaar,
            termcode: 9999,
            MerchantID: '',
            CustomerID: String(this.res_Reciept.ReceiptNo),
            Filler1: 'NA',
            TxnAmount: String(this.resp_singlebatch.Formamount),
            // TxnAmount: nTranscationamount,
            // "TxnAmount": "1",
            BankID: 'NA',
            Filler2: 'NA',
            Filler3: 'NA',
            CurrencyType: 'INR',
            ItemCode: 'NA',
            TypeField1: 'R',
            SecurityID: '',
            Filler4: 'NA',
            Filler5: 'NA',
            TypeField2: 'F',
            AdditionalInfo1: String(this.oSession.finyear),
            AdditionalInfo2: '',
            AdditionalInfo3: String(this.resp_singlebatch.Batch_code),
            AdditionalInfo4: String(this.oSession.aadhaar),
            AdditionalInfo5: '9999',
            AdditionalInfo6: '1',
            AdditionalInfo7: String(this.res_Reciept.ReceiptID),
            TypeField3: 'NA',
            Feestype: 'FORMFEES',
        };
        let input_json = {
            Input: encryptUsingAES256(jsonin),
        };
        this.commonService
            .Post_json_data<string>(Students_url.BillDeskcheckSum, input_json)
            .subscribe((response) => {
                this.billdeskRequestMsg = response.data;
                if (this.billdeskRequestMsg != null) {
                    BilldeskPay(this.billdeskRequestMsg, "", "");
                }
                // this.StudentAppliedCourses();
            });
    }

    onSelect_semester() {
        this.groupedData = {}
        this.arraypush = []
        this.table_one = []
        this.table_two = []
    }

    PortalOpen() {
        // this.portal = "";
        // this.BatchCode = event.Batch_Code;
        // this.formAmount = event.FormAmount;

        this.form.reset()
        let sPortalopenUrl = myGlobals.Domainname
        let jsonin = {
            finyear: this.oSession.finyear,
            collegecode: this.oSession.collegecode,
            batchcode: this.resp_singlebatch.Batch_code,
            Webportal: sPortalopenUrl
        };
        let jsonin_input = {
            Input: encryptUsingAES256(jsonin),
        };
        this.commonService
            .Post_json_data<Ires_PhdBatchs>(Students_url.PortalOpenv1, jsonin_input)
            .subscribe((response) => {
                this.portal = response.data
                if (this.portal.Admissionstarted == false && this.portal.Admissionyear == Global_CurrentFinYear) {
                    this.globalmessage.Show_error('Admission not started')
                    this.router.navigate(['dashboard'])
                    return
                }
                this.subjectgroup_d_list()
            })
    }

    student_selectedsubjectthird() {
        let jsonin = {
            finyear: this.oSession.finyear,
            college_code: this.oSession.collegecode,
            aadhaar: this.oSession.aadhaar,
            Batch_code: this.oSession.currentformfeesbatchcode,
        };
        let jsonin_input = {
            Input: encryptUsingAES256(jsonin),
        };
        this.commonService
            .Post_json_data<Ires_subjectlist[]>(Students_url.student_selectedsubjectthird, jsonin_input)
            .subscribe((response) => {
                let tdata = response.data
                this.table_one_selected = tdata.filter((item) => item.Semester === 5);
                this.table_two_selected = tdata.filter((item) => item.Semester === 6);
                // this.portal = response.data
                // if(this.portal.Admissionstarted == false){
                //     this.globalmessage.Show_error('Admission not started')
                //     this.router.navigate(['dashboard'])
                //     return
                // }
                // this.subjectgroup_d_list()
            })
    }

    protected readonly filter = filter;
}
