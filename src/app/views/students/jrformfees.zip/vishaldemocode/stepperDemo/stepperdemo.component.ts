// import { JsonPipe, NgTemplateOutlet } from '@angular/common';
// import {Component, HostListener, signal} from '@angular/core';
// import {
//     BadgeComponent,
//     ButtonDirective,
//     ColComponent,
//     FormCheckComponent,
//     FormCheckInputDirective,
//     FormCheckLabelDirective,
//     FormControlDirective,
//     FormLabelDirective,
//     FormPasswordDirective,
//     FormSelectDirective,
//     InputGroupComponent,
//     InputGroupTextDirective,
//     RowComponent,
//     StepperComponent,
//     StepperStepComponent
// } from '@coreui/angular-pro';
// import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
// import {EducationDetailsComponent} from "../studentprofilenew/educationdetails/educationdetails.component";
// import {FinalSubmitComponent} from "../studentprofilenew/finalsubmit/finalsubmit.component";
// import {PersonalDetailsComponent} from "../studentprofilenew/personaldetails/personaldetail.component";
// import {ReservationDetailsComponent} from "../studentprofilenew/reservationdetails/reservationdetails.component";
//
// @Component({
//     selector: 'docs-stepper07',
//     imports: [
//         BadgeComponent,
//         ButtonDirective,
//         ColComponent,
//         FormCheckComponent,
//         FormCheckInputDirective,
//         FormCheckLabelDirective,
//         FormControlDirective,
//         FormLabelDirective,
//         FormPasswordDirective,
//         FormSelectDirective,
//         InputGroupComponent,
//         InputGroupTextDirective,
//         StepperComponent,
//         RowComponent,
//         NgTemplateOutlet,
//         ReactiveFormsModule,
//         FormsModule,
//         JsonPipe,
//         StepperStepComponent,
//         EducationDetailsComponent,
//         FinalSubmitComponent,
//         PersonalDetailsComponent,
//         ReservationDetailsComponent
//     ],
//     templateUrl: './stepperdemo.component.html',
//     styles: `
//     :host {
//       .btn {
//         margin-inline-end: 0.5rem;
//       }
//     }
//   `
// })
// export class Stepper07Component {
//
//     public stepperLayout: 'horizontal' | 'vertical' = 'horizontal';
//
//     ngOnInit() {
//         // Set the initial layout on component load
//         this.setLayout(window.innerWidth);
//     }
//
//
//     @HostListener('window:resize', ['$event'])
//     onResize(event: any) {
//         this.setLayout(event.target.innerWidth);
//     }
//
//     private setLayout(width: number): void {
//         // Define your breakpoint (e.g., 768px for a typical mobile/desktop split)
//         const breakpoint = 768;
//         if (width < breakpoint) {
//             this.stepperLayout = 'vertical'; // Vertical on mobile
//         } else {
//             this.stepperLayout = 'horizontal'; // Horizontal on desktop
//         }
//     }
//
//     readonly stepperForm: FormGroup = new FormGroup({
//         step_0: new FormGroup({
//             firstName: new FormControl('Lukasz', { validators: [Validators.required] }),
//             lastName: new FormControl('Holeczek', { validators: [Validators.required] }),
//             userName: new FormControl('', { validators: [Validators.required, Validators.minLength(5)] })
//         }),
//         step_1: new FormGroup({
//             address: new FormControl('Anchorage', { validators: [Validators.required] }),
//             state: new FormControl('AK', { validators: [Validators.required] }),
//             zip: new FormControl('99599', { validators: [Validators.required] })
//         }),
//         step_2: new FormGroup({
//             email: new FormControl('john@doe', { validators: [Validators.required, Validators.email] }),
//             password: new FormControl('', { validators: [Validators.required, Validators.minLength(5)] }),
//             terms: new FormControl(false, { validators: [Validators.requiredTrue] })
//         })
//     });
//
//     readonly formGroups = Object.values(this.stepperForm.controls);
//     readonly group_0 = this.stepperForm.get('step_0') as FormGroup;
//     readonly group_1 = this.stepperForm.get('step_1') as FormGroup;
//     readonly group_2 = this.stepperForm.get('step_2') as FormGroup;
//
//     readonly finished = signal(false);
//     readonly currentStep = signal(0);
//
//     handleReset() {
//         this.stepperForm.reset();
//         this.finished.set(false);
//     }
//
//     handleFinish(finish: boolean) {
//         if (!finish) {
//             return false;
//         }
//         const valid = this.currentFormGroupValid(this.currentStep());
//         if (!valid) {
//             // return false;
//         }
//         this.finished.set(finish);
//         return true;
//     }
//
//     handleNext(stepper: StepperComponent) {
//         const valid = this.currentFormGroupValid(this.currentStep());
//         if (!valid) {
//             // return false;
//         }
//         stepper.next();
//     }
//
//     currentFormGroupValid(step: number) {
//         const currentGroup = `group_${step}` as keyof Stepper07Component;
//         const currentFormGroup = this[currentGroup] as FormGroup;
//         currentFormGroup.markAllAsTouched();
//         return currentFormGroup?.valid;
//     }
//
//     readonly states = [
//         { name: 'Alabama', code: 'AL' },
//         { name: 'Alaska', code: 'AK' }
//     ];
//
// }



import { JsonPipe, NgTemplateOutlet } from '@angular/common';
import {Component, HostListener, signal} from '@angular/core';
import {
    BadgeComponent,
    ButtonDirective,
    ColComponent,
    FormCheckComponent,
    FormCheckInputDirective,
    FormCheckLabelDirective,
    FormControlDirective,
    FormLabelDirective,
    FormPasswordDirective,
    FormSelectDirective,
    InputGroupComponent,
    InputGroupTextDirective,
    RowComponent,
    StepperComponent,
    StepperStepComponent
} from '@coreui/angular-pro';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import {PersonalDetailsComponent} from "../../studentprofilenew/personaldetails/personaldetail.component";
import {ReservationDetailsComponent} from "../../studentprofilenew/reservationdetails/reservationdetails.component";
import {EducationDetailsComponent} from "../../studentprofilenew/educationdetails/educationdetails.component";
import {FinalSubmitComponent} from "../../studentprofilenew/finalsubmit/finalsubmit.component";

@Component({
    selector: 'docs-stepper07',
    imports: [
        BadgeComponent,
        ButtonDirective,
        ColComponent,
        FormCheckComponent,
        FormCheckInputDirective,
        FormCheckLabelDirective,
        FormControlDirective,
        FormLabelDirective,
        FormPasswordDirective,
        StepperComponent,
        RowComponent,
        NgTemplateOutlet,
        ReactiveFormsModule,
        FormsModule,
        JsonPipe,
        StepperStepComponent,
        PersonalDetailsComponent,
        ReservationDetailsComponent,
        EducationDetailsComponent,
        FinalSubmitComponent,
    ],
    standalone: true,
    templateUrl: './stepperdemo.component.html',
    styleUrl: './stepperdemo.component.scss',
    styles: `
      :host {
        .btn {
          margin-inline-end: 0.5rem;
        }
      }
    `
})
export class Stepper07Component {

    // public stepperLayout: 'horizontal' | 'vertical' = 'horizontal';
    currentLayout: 'horizontal' | 'vertical' = window.innerWidth > 768 ? 'horizontal' : 'vertical';
    currentStepButtonLayout: 'horizontal' | 'vertical' = window.innerWidth > 768 ? 'vertical' : 'horizontal';

    ngOnInit() {
        // Set the initial layout on component load
        // this.setLayout(window.innerWidth);
        this.updateLayout();
    }

    @HostListener('window:resize', ['$event'])
    onResize(event: any) {
        this.updateLayout();
    }

    updateLayout(): void {
        // Assuming a breakpoint around 768px (CoreUI's md breakpoint is >= 768px)
        const isDesktop = window.innerWidth >= 768;

        // Desktop: layout horizontal, button layout vertical (text below icon)
        // Mobile: layout vertical, button layout horizontal (text beside icon)
        this.currentLayout = isDesktop ? 'horizontal' : 'vertical';
        // When layout is vertical, stepButtonLayout prop has no effect, we control text orientation with CSS
        // The key styling will be done in SCSS
    }

    readonly stepperForm: FormGroup = new FormGroup({
        step_0: new FormGroup({
            firstName: new FormControl('Lukasz', { validators: [Validators.required] }),
            lastName: new FormControl('Holeczek', { validators: [Validators.required] }),
            userName: new FormControl('', { validators: [Validators.required, Validators.minLength(5)] })
        }),
        step_1: new FormGroup({
            address: new FormControl('Anchorage', { validators: [Validators.required] }),
            state: new FormControl('AK', { validators: [Validators.required] }),
            zip: new FormControl('99599', { validators: [Validators.required] })
        }),
        step_2: new FormGroup({
            email: new FormControl('john@doe', { validators: [Validators.required, Validators.email] }),
            password: new FormControl('', { validators: [Validators.required, Validators.minLength(5)] }),
            terms: new FormControl(false, { validators: [Validators.requiredTrue] })
        })
    });

    readonly formGroups = Object.values(this.stepperForm.controls);
    readonly group_0 = this.stepperForm.get('step_0') as FormGroup;
    readonly group_1 = this.stepperForm.get('step_1') as FormGroup;
    readonly group_2 = this.stepperForm.get('step_2') as FormGroup;

    readonly finished = signal(false);
    readonly currentStep = signal(0);

    handleReset() {
        this.stepperForm.reset();
        this.finished.set(false);
    }

    handleFinish(finish: boolean) {
        if (!finish) {
            return false;
        }
        const valid = this.currentFormGroupValid(this.currentStep());
        if (!valid) {
            // return false;
        }
        this.finished.set(finish);
        return true;
    }

    handleNext(stepper: StepperComponent) {
        const valid = this.currentFormGroupValid(this.currentStep());
        if (!valid) {
            // return false;
        }
        stepper.next();
    }

    currentFormGroupValid(step: number) {
        const currentGroup = `group_${step}` as keyof Stepper07Component;
        const currentFormGroup = this[currentGroup] as FormGroup;
        currentFormGroup.markAllAsTouched();
        return currentFormGroup?.valid;
    }

    readonly states = [
        { name: 'Alabama', code: 'AL' },
        { name: 'Alaska', code: 'AK' }
    ];
}