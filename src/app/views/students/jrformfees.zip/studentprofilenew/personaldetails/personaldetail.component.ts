import {Component, Input, OnInit} from "@angular/core";
import {
    AccordionButtonDirective, AccordionComponent, AccordionItemComponent, BadgeComponent, ButtonDirective,
    CalloutComponent,
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent, CardTextDirective, CardTitleDirective,
    ColComponent, FormCheckComponent, FormCheckInputDirective, FormControlDirective, FormDirective, FormLabelDirective,
    FormSelectDirective,
    RowComponent, SpinnerComponent, TabContentComponent, TabPaneComponent, TemplateIdDirective
} from "@coreui/angular-pro";
import {ImageCroppedEvent, ImageCropperComponent, ImageTransform, LoadedImage} from "ngx-image-cropper";
import {FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators} from "@angular/forms";
import {
    Ires_parents,
    Ires_personaldata,
    Ires_personalinfo,
    Parents,
    Res_ProfileResources
} from "../../../../models/response";
import {Sessiondata} from "../../../../models/Sessiondata";
import {encryptUsingAES256} from "../../../../globals/encryptdata";
import {GlobalMessage} from "../../../../globals/global.message";
import {StudentprofileService} from "../../studentprofile/studentprofile.service";
import {DomSanitizer} from "@angular/platform-browser";
import {Students_url} from "../../../../globals/global-api";
import {CommonService} from "../../../../globals/common.service";
import {mobileValidator} from "../../../../globals/aadhaar_validator";
import {Router} from "@angular/router";
import {SessionService} from "../../../../globals/sessionstorage";
import {Uppercase} from "../../../../uppercase";

@Component({
    selector: "app-personaldetail",
    templateUrl: './personaldetail.component.html',
    styleUrls: ['./personaldetail.component.scss'],
    standalone: true,
    imports: [
        CardBodyComponent,
        CardComponent,
        ColComponent,
        RowComponent,
        AccordionButtonDirective,
        AccordionComponent,
        AccordionItemComponent,
        BadgeComponent,
        ButtonDirective,
        CalloutComponent,
        CardTextDirective,
        CardTitleDirective,
        FormCheckComponent,
        FormCheckInputDirective,
        FormControlDirective,
        FormDirective,
        ImageCropperComponent,
        ReactiveFormsModule,
        SpinnerComponent,
        TemplateIdDirective,
        Uppercase,
        FormLabelDirective,
        FormSelectDirective

    ]
})

export class PersonalDetailsComponent implements OnInit {

    // studentDetailsForm!: FormGroup;
    Profilepictform!: FormGroup;
    @Input() parentDetailsForm!: FormGroup;
    @Input() addressDetailsForm!: FormGroup;
    @Input() nationalitynomineeForm!: FormGroup;
    @Input() otherDetailsForm!: FormGroup;
    // @Input() reservationdetailForm!: FormGroup;
    @Input() checkfinalSubmit!: FormGroup;

    get_personaldetail!: Ires_personaldata;
    ires_parents!: Ires_personalinfo

    oSession!: Sessiondata;
    Ires_ProfileResources!: Res_ProfileResources

    private pngsignfilename: string = '';
    public imageURL!: string;
    public signimageURL!: string;

    croppedImage: any = '';
    imageChangedEvent: any = '';
    private pngfilename: string = '';
    imageChanged_signEvent: any = '';
    croppedsignImage: any = '';

    relation = [''];
    occupation = [''];
    annual_income = [''];
    location_area = [''];
    country = [''];
    state = [''];
    nominee_relation = [''];
    bloodgroup = [''];
    district = [''];
    gender = [''];
    religion = [''];
    mother_tongue = [''];
    martial_status = [''];
    reservation = [''];
    category = [''];
    specially_abled = [''];
    activity = [''];
    participation_level = [''];
    secured_rank = [''];
    board: any;

    ProfilephotoImage: any;
    SignatureImage: any;
    Ires_photo: any;

    transform: ImageTransform = {};
    signtransform: ImageTransform = {};

    containWithinAspectRatio = false;
    tabfivedisable = true;
    checkbox_personal: boolean = false;
    hidepersonaltab = false;
    checkbox_percentage: boolean = true;
    uploadphotoloader = false;
    openoneacc = false;
    opentwoacc = false;
    submitted = false;
    saveparentsloader = false;
    IU_parentdetails: boolean = false;
    addressloader = false;
    nationalitynomineeloader = false;
    otherdetailsloader = false;
    personalsubmitted: boolean = true;

    private Uploadprofilepicture!: File;
    private Uploadsignfile!: File;

    canvasRotation = 0;
    signcanvasRotation = 0;


    constructor(
        private commonService: CommonService,
        private globalmessage : GlobalMessage,
        private studentprofieservice: StudentprofileService,
        private sanitizer: DomSanitizer,
        private formBuilder: FormBuilder,
        private router: Router,
        private sessionservice: SessionService
    ) {
    }

    ngOnInit() {
        this.oSession = new Sessiondata(this.sessionservice);
        this.oSession.Getdatafromstroage();

        this.Createform();
        this.ProfileResource();
    }

    Createform() {

        this.Profilepictform = this.formBuilder.group({
            upload: ['', Validators.required],
            upload_signature: ['', Validators.required],
            picture: [''],
            croped: [''],
            picture_sign: [''],
            croped_sign: [''],
        });

            this.parentDetailsForm = this.formBuilder.group({
            parentsemailid: ['', Validators.required, Validators.maxLength(50)],
            parentsmobile: ['', [mobileValidator]],
            relationtype: ['', Validators.required],
            occupation_guardian: ['', Validators.required],
            annual_income: [''],
            ebc: [''],
        });

        this.addressDetailsForm = this.formBuilder.group({
            correpondence_flatno: ['', Validators.required, Validators.maxLength(150)],
            correpondence_colonyname: [
                '',
                [Validators.required, Validators.maxLength(150)],
            ],
            correpondence_villagename: ['', Validators.maxLength(150)],
            correpondence_landmark: ['', Validators.maxLength(150)],
            correpondence_location_area: ['', Validators.required],
            correpondence_country: ['', Validators.required],
            correpondence_state: ['', Validators.required],
            correpondence_district: ['', Validators.required, Validators.maxLength(30)],
            correpondence_city: ['', [Validators.required, Validators.maxLength(30)]],
            correpondence_pincode: [
                '',
                [Validators.required, Validators.minLength(6), Validators.maxLength(6)],
            ],
            permanent_flatno: ['', Validators.required, Validators.maxLength(150)],
            permanent_colonyname: [
                '',
                [Validators.required, Validators.maxLength(150)],
            ],
            permanent_villagename: ['', Validators.maxLength(150)],
            permanent_landmark: ['', Validators.maxLength(150)],
            permanent_location_area: ['', Validators.required],
            permanent_country: ['', Validators.required],
            permanent_state: ['', Validators.required],
            permanent_district: ['', Validators.required, Validators.maxLength(60)],
            permanent_city: ['', [Validators.required, Validators.maxLength(30)]],
            permanent_pincode: [
                '',
                [Validators.required, Validators.minLength(6), Validators.maxLength(6)],
            ],
            same_as_permenant: [''],
        });

        this.nationalitynomineeForm = this.formBuilder.group({
            country: ['', Validators.required],
            state: ['', Validators.required],
            nomineename: ['', Validators.required, Validators.maxLength(100)],
            nomineedob: ['', Validators.required],
            nomineerelation: ['', Validators.required],
        });

        this.otherDetailsForm = this.formBuilder.group({
            Pan: ['', Validators.maxLength(20)],
            voterid: ['', Validators.maxLength(20)],
            educationgap: ['', Validators.required],
            bloodgroup: [''],
            maxqualification_family: ['', Validators.maxLength(20)],
            organ_donation: [''],
        });

        this.checkfinalSubmit = this.formBuilder.group({
            checkprofile: ['', Validators.required],
        });

        if (this.oSession.isprofilesubmited == 'true') {
            this.tabfivedisable = true
            this.Profilepictform.disable();
            this.parentDetailsForm.disable();
            this.addressDetailsForm.disable();
            this.nationalitynomineeForm.disable();
            this.otherDetailsForm.disable();
            this.checkfinalSubmit.disable();
        }
        if (this.oSession.formfeesrecieved == 'NOTPAID') {
            this.router.navigate(['/formfees'])
        }

        this.personalInfo();

       // this.getPersonalInfo();
    }

    outsidechange($event: number) {
        if ($event == 1) {
            this.Clear_firsttabobjects()
        }
    }

    Clear_firsttabobjects() {
    }

    get picture_fld() {
        return this.Profilepictform.get('picture');
    }

    showPreview(event: any) {
        this.pngsignfilename = (this.oSession.aadhaar! + Math.random()).toString();
        this.imageChangedEvent = event;
        const file = (event.target as HTMLInputElement).files![0];
        // if (!file) return;
        // const img = new Image();
        // img.src = URL.createObjectURL(file);
        // img.onload = async () => {
        //     const result = await this.detectFace(img);
        //     let faceCount = await this.getFaceCount(img);
        //     if (faceCount > 1) {
        //         alert(`Total face Found: ${faceCount}`); // Will show Yes or No
        //         return
        //     }
        //     alert(`Face Found: ${result}`); // Will show Yes or No
        // };
        /*
        if (file.size > 50000) {
          this.globalmessage.Show_error('File size is more than 5 MB.');
          this.Profilepictform.reset();
          return;
        }
        */
        /*
        if (file.type != 'image/png') {
          this.globalmessage.Show_error('Only .png file allowed!');
          this.Profilepictform.reset();
          return;
        }
        */
        this.Profilepictform.patchValue({picture: file});
        this.Profilepictform.get('picture')!.updateValueAndValidity();
        // File Preview
        const reader = new FileReader();
        reader.onload = () => {
            this.imageURL = reader.result as string;
            this.croppedImage = reader.result as string;
        };
        reader.readAsDataURL(file);
    }

    imageCropped(event: ImageCroppedEvent) {
        this.croppedImage = this.sanitizer.bypassSecurityTrustUrl(event.objectUrl!);
        const filebeforecorp = this.imageChangedEvent.target.files[0];
        this.Uploadprofilepicture = new File([event.blob!], filebeforecorp.name, {
            type: 'PNG',
        });
    }

    imageLoaded(image: LoadedImage) {
        // show cropper
    }

    cropperReady() {
        // cropper ready
    }

    loadImageFailed() {
        this.globalmessage.Show_message('Issue while loading image.');
        // show message
    }

    imagesignLoaded(image: LoadedImage) {
        // show cropper
    }

    loadSignImageFailed() {
        this.globalmessage.Show_message('Issue while loading image.');
        // show message
    }

    cropperSignReady() {
        // cropper ready
    }

    Finalsubmit_enable() {
        // if (
        //     this.get_personaldetail.pagesubmited == true &&
        //     this.get_personaldetail.reservationsubmited == true &&
        //     this.get_personaldetail.educationsubmited == true
        // ) {
        //
        //
        //
        //
        // }
    }

    get pdf() {
        return this.parentDetailsForm.controls;
    }

    get adf() {
        return this.addressDetailsForm.controls;
    }

    get nnf() {
        return this.nationalitynomineeForm.controls;
    }

    get odf() {
        return this.otherDetailsForm.controls;
    }

    UploadImage() {
        let jsonin = {
            Collegecode: this.oSession.collegecode,
            Finyear: this.oSession.finyear,
            Aadhaar: this.oSession.aadhaar,
        };
        this.uploadphotoloader = true
        let formdata = new FormData();
        formdata.append('input_form', encryptUsingAES256(jsonin));
        formdata.append('files', this.Uploadprofilepicture);
        formdata.append('files', this.Uploadsignfile);
        this.studentprofieservice
            .Upload_profile_photo(formdata)
            .subscribe((response: any) => {
                this.Ires_photo = response.data;
                this.globalmessage.Show_message('Data uploaded successfully.');
                this.uploadphotoloader = false
                // this.getPersonalInfo();
            });
    }

    Check_alleducation_filled() {
        let lBreak = false
        this.checkbox_percentage = true    //disable
        for (const edu of this.get_personaldetail.education) {
            if (edu.sgpa_percentage <= 0) {
                lBreak = true
                break;
                //this.checkbox_percentage = false
                //break;
            }
        }
        if (!lBreak) {
            this.checkbox_percentage = false
        }
    }

    showPreview_sign(event: any) {
        this.pngfilename = (this.oSession.aadhaar! + Math.random()).toString();
        this.imageChanged_signEvent = event;
        const file = (event.target as HTMLInputElement).files![0];
        this.Profilepictform.patchValue({picture: file});
        this.Profilepictform.get('picture')!.updateValueAndValidity();
        // File Preview
        const reader = new FileReader();
        reader.onload = () => {
            this.signimageURL = reader.result as string;
            this.croppedsignImage = reader.result as string;
        };
        reader.readAsDataURL(file);
    }

    image_signCropped(event: ImageCroppedEvent) {
        this.croppedsignImage = this.sanitizer.bypassSecurityTrustUrl(
            event.objectUrl!
        );
        const filebeforecorp = this.imageChanged_signEvent.target.files[0];
        this.Uploadsignfile = new File([event.blob!], filebeforecorp.name, {
            type: 'PNG',
        });
    }

    IU_Parents() {
        this.parentDetailsForm.addControl('finyear', new FormControl('', []));
        this.parentDetailsForm.controls['finyear'].setValue(this.oSession.finyear);
        this.parentDetailsForm.addControl('college_code', new FormControl('', []));
        this.parentDetailsForm.controls['college_code'].setValue(
            this.oSession.collegecode
        );
        this.parentDetailsForm.addControl('aadhaar', new FormControl('', []));
        this.parentDetailsForm.controls['aadhaar'].setValue(this.oSession.aadhaar);
        this.saveparentsloader = true;
        let input_json = {
            Input: encryptUsingAES256(this.parentDetailsForm.value),
        };
        this.studentprofieservice
            .IU_Parents(input_json)
            .subscribe((response) => {
                if (response == null) {
                    this.globalmessage.Show_error('Please check your details');
                }
                this.IU_parentdetails = response;
                // this.getPersonalInfo();
                this.globalmessage.Show_message('Data uploaded successfully');
                this.saveparentsloader = false;
            });
    }

    updateAddress(event: string) {
        if (event == 'Yes') {
            this.addressDetailsForm.controls['permanent_flatno'].setValue(
                this.addressDetailsForm.controls['correpondence_flatno'].value)
            this.addressDetailsForm.controls['permanent_colonyname'].setValue(
                this.addressDetailsForm.controls['correpondence_colonyname'].value)
            this.addressDetailsForm.controls['permanent_villagename'].setValue(
                this.addressDetailsForm.controls['correpondence_villagename'].value)
            this.addressDetailsForm.controls['permanent_landmark'].setValue(
                this.addressDetailsForm.controls['correpondence_landmark'].value)
            this.addressDetailsForm.controls['permanent_location_area'].setValue(
                this.addressDetailsForm.controls['correpondence_location_area'].value)
            this.addressDetailsForm.controls['permanent_country'].setValue(
                this.addressDetailsForm.controls['correpondence_country'].value)
            this.addressDetailsForm.controls['permanent_state'].setValue(
                this.addressDetailsForm.controls['correpondence_state'].value)
            this.addressDetailsForm.controls['permanent_district'].setValue(
                this.addressDetailsForm.controls['correpondence_district'].value)
            this.addressDetailsForm.controls['permanent_city'].setValue(
                this.addressDetailsForm.controls['correpondence_city'].value)
            this.addressDetailsForm.controls['permanent_pincode'].setValue(
                this.addressDetailsForm.controls['correpondence_pincode'].value)
        } else {
            this.addressDetailsForm.controls['permanent_flatno'].setValue('')
            this.addressDetailsForm.controls['permanent_colonyname'].setValue('')
            this.addressDetailsForm.controls['permanent_villagename'].setValue('')
            this.addressDetailsForm.controls['permanent_landmark'].setValue('')
            this.addressDetailsForm.controls['permanent_location_area'].setValue('')
            this.addressDetailsForm.controls['permanent_country'].setValue('')
            this.addressDetailsForm.controls['permanent_state'].setValue('')
            this.addressDetailsForm.controls['permanent_district'].setValue('')
            this.addressDetailsForm.controls['permanent_city'].setValue('')
            this.addressDetailsForm.controls['permanent_pincode'].setValue('')
        }
    }

    IU_Address() {
        this.addressDetailsForm.addControl('finyear', new FormControl('', []));
        this.addressDetailsForm.controls['finyear'].setValue(this.oSession.finyear);
        this.addressDetailsForm.addControl('college_code', new FormControl('', []));
        this.addressDetailsForm.controls['college_code'].setValue(
            this.oSession.collegecode
        );
        this.addressDetailsForm.addControl('aadhaar', new FormControl('', []));
        this.addressDetailsForm.controls['aadhaar'].setValue(this.oSession.aadhaar);
        this.addressloader = true
        let input_json = {
            Input: encryptUsingAES256(this.addressDetailsForm.value),
        };
        this.studentprofieservice
            .IU_Address(input_json)
            .subscribe((response) => {
                if (response == null) {
                    this.globalmessage.Show_error('Please check your details');
                }
                this.IU_parentdetails = response;
                this.globalmessage.Show_successmessage('Data uploaded successfully');
                this.addressloader = false;
                // this.getPersonalInfo()
            });
    }

    IU_Nationalty() {
        this.nationalitynomineeForm.addControl('finyear', new FormControl('', []));
        this.nationalitynomineeForm.controls['finyear'].setValue(
            this.oSession.finyear
        );
        this.nationalitynomineeForm.addControl(
            'college_code',
            new FormControl('', [])
        );
        this.nationalitynomineeForm.controls['college_code'].setValue(
            this.oSession.collegecode
        );
        this.nationalitynomineeForm.addControl('aadhaar', new FormControl('', []));
        this.nationalitynomineeForm.controls['aadhaar'].setValue(
            this.oSession.aadhaar
        );
        this.nationalitynomineeloader = true
        let input_json = {
            Input: encryptUsingAES256(this.nationalitynomineeForm.value),
        };
        this.studentprofieservice
            .IU_Nationalty(input_json)
            .subscribe((response) => {
                if (response == null) {
                    this.globalmessage.Show_error('Please check your details');
                }
                this.IU_parentdetails = response;
                // this.getPersonalInfo();
                this.globalmessage.Show_message('Data uploaded successfully');
                this.nationalitynomineeloader = false
            });
    }

    ProfileResource() {
        this.studentprofieservice
            .ProfileResource("")
            .subscribe((response) => {
                this.Ires_ProfileResources = response.data
                this.relation = this.Ires_ProfileResources.Relation_Type
                this.occupation = this.Ires_ProfileResources.occupation_guardian
                this.annual_income = this.Ires_ProfileResources.annual_income
                this.location_area = this.Ires_ProfileResources.Location_Area
                this.country = this.Ires_ProfileResources.country
                this.state = this.Ires_ProfileResources.State
                this.district = this.Ires_ProfileResources.district
                this.bloodgroup = this.Ires_ProfileResources.BloodGroup
                this.nominee_relation = this.Ires_ProfileResources.Nominee_Relation
                this.gender = this.Ires_ProfileResources.sex
                this.religion = this.Ires_ProfileResources.Religion
                this.mother_tongue = this.Ires_ProfileResources.mother_tongue
                this.martial_status = this.Ires_ProfileResources.Marital_Status
                this.reservation = this.Ires_ProfileResources.parallel_horizontal_reservation
                this.category = this.Ires_ProfileResources.category.slice(1)
                this.specially_abled = this.Ires_ProfileResources.specially_abled
                this.activity = this.Ires_ProfileResources.activity
                this.participation_level = this.Ires_ProfileResources.participation_level
                this.secured_rank = this.Ires_ProfileResources.secured_rank
                this.board = this.Ires_ProfileResources.College_University
            });
    }

    IU_Others() {
        this.otherDetailsForm.addControl('finyear', new FormControl('', []));
        this.otherDetailsForm.controls['finyear'].setValue(this.oSession.finyear);
        this.otherDetailsForm.addControl('college_code', new FormControl('', []));
        this.otherDetailsForm.controls['college_code'].setValue(
            this.oSession.collegecode
        );
        this.otherDetailsForm.addControl('aadhaar', new FormControl('', []));
        this.otherDetailsForm.controls['aadhaar'].setValue(this.oSession.aadhaar);
        this.otherdetailsloader = true
        let input_json = {
            Input: encryptUsingAES256(this.otherDetailsForm.value),
        };
        this.studentprofieservice
            .IU_Others(input_json)
            .subscribe((response) => {
                if (response == null) {
                    this.globalmessage.Show_error('Please check your details');
                }
                this.IU_parentdetails = response;
                // this.getPersonalInfo();
                this.globalmessage.Show_message('Data uploaded successfully');
                this.otherdetailsloader = false
            });
    }

    PersonalSubmit() {
        // if()
        // this.submitpage = 1
        let jsonin = {
            finyear: this.oSession.finyear,
            college_code: this.oSession.collegecode,
            aadhaar: this.oSession.aadhaar,
            // pagesubmited: pagesubmitted
        };
        let input_json = {
            Input: encryptUsingAES256(jsonin),
        };
        this.commonService
            .Post_json_data<boolean>(Students_url.IU_personalsubmited, input_json)
            .subscribe((response) => {
                if (response == null) {
                    this.globalmessage.Show_error('Please check your data');
                }
                this.personalsubmitted = response.data;
                this.globalmessage.Show_successmessage('Data submitted successfully.')
                // this.getPersonalInfo();
            });
    }

    personalInfo(){

        let nBatchcode = 0

        if (this.oSession.currentformfeesbatchcode! <= 0) {
            nBatchcode = this.oSession.maxbatchcode!
        } else {
            nBatchcode = this.oSession.currentformfeesbatchcode!
        }

        let payload = {
            College_code: this.oSession.collegecode,
            Finyear: this.oSession.finyear,
            Aadhaar: this.oSession.aadhaar,
            batch_code: nBatchcode
        };

        let input_json = {
            Input: encryptUsingAES256(payload),
        };

        this.commonService.Post_json_data<Ires_personalinfo>(Students_url.personalinfo, (input_json)).subscribe((response) => {

            this.ires_parents = response.data
            // console.log('resspersss', this.ires_parents)

            // this.Profilepictform.patchValue(this.ires_parents);
            this.parentDetailsForm.patchValue(this.ires_parents.parents);
            this.addressDetailsForm.patchValue(this.ires_parents.address);
            this.nationalitynomineeForm.patchValue(this.ires_parents.nationality);
            this.otherDetailsForm.patchValue(this.ires_parents.other);
            // this.reservationdetailForm.patchValue(this.ires_parents.reservation);
        })

    }


}