import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { JrstudentprofileComponent } from './jrstudentprofile.component';

const routes: Routes = [
  {
    path: '',
    component: JrstudentprofileComponent,
    data: {
      title: 'Fill Profile'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class JrstudentprofileRoutingModule {}
