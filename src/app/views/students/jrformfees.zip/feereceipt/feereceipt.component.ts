import {Component, effect, OnInit, signal, ViewChild} from '@angular/core';
import {ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup, Validators,} from '@angular/forms';
import {Router} from '@angular/router';
import {FeereceiptService} from './feereceipt.service';
import {GlobalMessage} from "../../../globals/global.message";
import {
  ApprovedCourse,
  Ires_allreciepts,
  IRes_downloadsinglereceipt,
  IRes_singlereceipt,
  PaidInstallments_M
} from "../../../models/response";
import {CommonService} from "../../../globals/common.service";
import {IBatchname, Ifinyear} from "./feereceipt.responsemodel";
import {SessionService} from "../../../globals/sessionstorage";
import {Sessiondata} from "../../../models/Sessiondata";
import {encryptUsingAES256} from "../../../globals/encryptdata";
import {
    ButtonDirective,
    CardBodyComponent,
    CardComponent, CardHeaderComponent,
    ColComponent, IColumn, ImgDirective,
    RowComponent,
    SmartTableComponent, SpinnerComponent,
} from "@coreui/angular-pro";

import {downloadstudentreceipt, Students_url} from "../../../globals/global-api";
import {DomSanitizer, SafeResourceUrl} from "@angular/platform-browser";
import {Extractguid, UDownloadfiles} from "../../../globals/global_utility";

@Component({
  selector: 'app-feereceipt',
  templateUrl: './feereceipt.component.html',
  styleUrls: ['./feereceipt.component.scss'],
    imports: [
        CardComponent,
        CardBodyComponent,
        ReactiveFormsModule,
        RowComponent,
        ColComponent,
        SmartTableComponent,
        CardHeaderComponent,
        ImgDirective,
        SpinnerComponent,
        ButtonDirective
    ],
  standalone: true
})
export class FeereceiptComponent implements OnInit {
  @ViewChild('tableRef') tableElement: any;
  Rjcollegeemail: string = "rjcollege@rjcollege.edu.in"
  data: any;
  FeereceiptForm!: UntypedFormGroup;
  Lineitem: any;
  Amount: any;
  InstallmentID: any;
  PrefixName: any;
  ReceiptNo: any;
  ReceiptDate: any;
  Installments: PaidInstallments_M[] = [];
  index: any;
  Header: any;
  submitted = false;
  Batch: any;
  FullName: any;
  Mobile: any;
  BatchName: any;
  Email: any;
  BilldeskTranID: any;
  ApprovedCourses: ApprovedCourse[]=[];
  FeeReceipt = false;
  FeeModal = true;
  FeeStructure: any;
  private gridApi: any;
  private gridColumnApi: any;
  rowss: any = [];
  gridOptions: any;
  public rowSelection: 'single' | 'multiple' = 'single';
  BatchNames:IBatchname[]=[];
  SelectedBatchs= {} as IBatchname;
  Finyear:Ifinyear[]=[];
  SelectedFinyear= {} as Ifinyear;
  Finyearnumber: any;
  allreceipts:Ires_allreciepts[]=[];
  selectednode= {} as Ires_allreciepts;
  oSession!: Sessiondata;
  ReceiptDetails= {} as IRes_singlereceipt;
  viewButton = false;

  activePage = 1;

  reciept_img: SafeResourceUrl = '';

  columns: (IColumn | string)[] = [
    {key: 'Receiptno', filter: false, sorter: false, _style: {width: '15%'}, _classes: 'text-muted small'},
    {key: 'Receiptamount', filter: false, sorter: false, _style: {width: '15%'}, _classes: 'text-muted small'},
    {key: 'Billdesktranid', filter: false, sorter: false, _style: {width: '15%'}, _classes: 'text-muted small'},
    {key: 'Payment_mode', filter: false, sorter: false, _style: {width: '15%'}, _classes: 'text-muted small'},
    {key: 'Batch_name', filter: false, sorter: false, _style: {width: '15%'}, _classes: 'text-muted small'},
    {key: 'Transactionguid', filter: false, sorter: false, _style: {width: '15%'}, _classes: 'text-muted small'},
  ];

  readonly signal_users = signal<Ires_allreciepts[]>([]);
  readonly signal_selectedId = signal<number | undefined>(0);
  itemsPerPage = 10;
  nSelectedReceipt: number = 0;

  downloadloader = false

  constructor(
    private router: Router, private commonService: CommonService,
    private feereceiptService: FeereceiptService,private sanitizer: DomSanitizer,
    private formBuilder: UntypedFormBuilder, private sessionservice: SessionService,
    private globalmessage: GlobalMessage
  ) {
    this.oSession = new Sessiondata(this.sessionservice)
    this.oSession.Getdatafromstroage();
    this.loadUsers()
    effect(() => {
      this.signal_users.set(this.getReceipts(this.signal_selectedId()));
    });
  }

  loadUsers() {
    this.Get_allreceipts(this.oSession.finyear, this.oSession.collegecode, this.oSession.aadhaar);
  }

  get f() {
    return this.FeereceiptForm.controls;
  }

  print() {
    // tslint:disable-next-line:no-unused-expression
    window && window.print();
  }

  ngOnInit(): void {
    this.oSession = new Sessiondata(this.sessionservice)
    this.oSession.Getdatafromstroage();
    this.Createform();
    this.GetFinyearAPI();
    this.get_recieptDetails();
  }

  Createform() {
    this.FeereceiptForm = this.formBuilder.group({
      finyear: ['', Validators.required],
      batch: ['', Validators.required],
      installment: ['', Validators.required],
    });
  }

  StudentApprovedCourses() {
    let jsonin = {
      Finyear: this.SelectedFinyear.Finyear,
      Collegecode: this.oSession.collegecode,
      Aadhaar: this.oSession.aadhaar,
    };
    let input_jsonin = {
      Input: encryptUsingAES256(jsonin)
    };
    this.feereceiptService.StudentApprovedCourses(input_jsonin)
      .subscribe((response) => {
        if (response == null) {
          return;
        }
        this.ApprovedCourses = response.data;
      });
  }

  GetFinyearAPI() {
    let jsonin = {
      Finyear: -99,
      Collegecode: this.oSession.collegecode,
      Aadhaar: this.oSession.aadhaar,
    };
    let input_jsonin = {
      Input: encryptUsingAES256(jsonin)
    };
    this.feereceiptService.Paidfinyear(input_jsonin).subscribe((response) => {
      if (response == null) {
        return;
      }
      this.Finyear = response.data;
    });
  }

  GetBatchAPI() {
    let jsonin = {
      Finyear: this.SelectedFinyear.Finyear,
      Collegecode: this.oSession.collegecode,
      Aadhaar: this.oSession.aadhaar,
    };
    let input_jsonin = {
      Input: encryptUsingAES256(jsonin)
    };
    this.feereceiptService.Paidbatchs_URL(input_jsonin).subscribe((response) => {
      if (response == null) {
        return;
      }
      this.BatchNames = response.data;
    });
  }

  onFinyearSelected() {
    this.GetBatchAPI();
  }

  onBatchSelected(event: any) {
    if (this.SelectedBatchs.Batch_code > 0) {
      this.ShowInstallmentDetailsv2();
    }
  }

  // ShowInstallmentDetails() {
  //     if (this.SelectedFinyear.Finyear <= 0) {
  //         this.openYesNoDialog('Select financial year');
  //         return;
  //     }
  //     this.submitted = true;
  //     let jsonin = {
  //         CollegeCode: this.oSession.collegecode,
  //         Finyear: this.SelectedFinyear.Finyear,
  //         BatchCode: this.SelectedBatchs.Batch_code,
  //         Aadhaar: this.oSession.aadhaar,
  //     };
  //
  //     let input_jsonin = {
  //         Input: encryptUsingAES256(jsonin)
  //     };
  //
  //     this.commonService.Post_json(StudentReceiptDetails_URL, input_jsonin)
  //         .subscribe((response) => {
  //             if (response == null) {
  //                 return;
  //             }
  //             this.Installments = response.data.Installments;
  //
  //             if (this.Installments != null) {
  //                 for (this.index of this.Installments) {
  //                     this.Header = this.index.Header;
  //                 }
  //             }
  //             // else {
  //             //   this.openYesNoDialog("")
  //             //   // alert(response.message)
  //             // }
  //         });
  //     this.StudentApprovedCourses();
  // }
  showFeesAmount() {
    this.Amount = this.FeeStructure.Header.Amount;
    this.InstallmentID = this.FeeStructure.Header.Installment;
    this.Finyearnumber = this.FeeStructure.Header.Finyear;
    this.PrefixName = this.FeeStructure.Header.Prefix_name;
    this.ReceiptNo = this.FeeStructure.Header.Receiptno;
    this.FullName = this.FeeStructure.Header.FullName;
    this.BatchName = this.FeeStructure.Header.BatchName;
    this.Mobile = this.FeeStructure.Header.Mobile;
    this.Email = this.FeeStructure.Header.Email;
    this.BilldeskTranID = this.FeeStructure.Header.BilldeskTranID;
    this.ReceiptDate = this.FeeStructure.Header.Receiptdate;
    this.Lineitem = this.FeeStructure.Lineitem;
  }

  ShowInstallmentDetailsv2() {
    this.submitted = true;
    let jsonin = {
      'CollegeCode': 1,
      'Finyear': this.SelectedFinyear.Finyear,
      'BatchCode': this.SelectedBatchs.Batch_code,
      'Aadhaar': this.oSession.aadhaar
    };
    let input_jsonin = {
      Input: encryptUsingAES256(jsonin)
    };
    this.feereceiptService.StudentReceiptDetailsv2(input_jsonin).subscribe(response => {
      if (response == null) {
        return;
      }
      this.Installments = response.data;
      // this.RemainingFees = response.data.Totalfees - this.Installments.I
    });
    this.StudentApprovedCourses();
  }

  showFeesAmountv2(index: any) {
    if (index <= 0) {
      return;
    }
    index = index - 1;
    let selectedrow = this.Installments[index];
    this.Amount = selectedrow.Amount;
    this.InstallmentID = selectedrow.Installment;
    this.PrefixName = selectedrow.Prefix_name;
    this.Finyearnumber = selectedrow.Finyear
    this.ReceiptNo = selectedrow.Receiptno;
    this.FullName = selectedrow.FullName;
    this.BatchName = selectedrow.BatchName;
    this.Mobile = selectedrow.Mobile;
    this.Email = selectedrow.Email;
    this.BilldeskTranID = selectedrow.BilldeskTranID;
    this.ReceiptDate = selectedrow.Receiptdate;
    this.Lineitem = selectedrow.Lineitem;
  }

  openYesNoDialog(msg: any) {
    this.globalmessage.Show_message('Delete');
  }

  showReceipt() {
    // this.FeeModal = false;
    this.FeeReceipt = true;
  }

  ChangeInstallment() {
    this.FeeModal = true;
    this.FeeReceipt = false;
    this.FeeStructure = '';
    this.Amount = '';
    this.resetPage();
  }

  resetPage() {
    let currentUrl = this.router.url;
    this.router.navigateByUrl('/', {skipLocationChange: true}).then(() => {
      this.router.navigate([currentUrl]);
    });
  }

  columnDefs = [
    {headerName: "Finyear", flex: 1, field: "Finyear", resizable: true},
    {headerName: "Receipt id", flex: 1, field: "Receipt_id", resizable: true},
    {headerName: "Batch Name", flex: 1, field: "Batch_name", resizable: true},
    {headerName: "BillDesk Transaction Id", flex: 1, field: "Billdesktranid", resizable: true},
    {headerName: "Amount", field: "Receiptamount", flex: 1, resizable: true},
  ]

  onGridReady(params: any) {
    this.gridApi = params.api;
    this.gridColumnApi = params.ColumnApi;
  }

  onSelectionChanged(event: any) {
    let selected_outnode = this.gridApi.getSelectedNodes();
    let out_rowselected = selected_outnode.map((node: { data: any; }) => node.data);
    this.selectednode = out_rowselected[0]
  }

  get_recieptDetails() {
    let jsonin = {
      CollegeCode: this.oSession.collegecode,
      Finyear: this.oSession.finyear,
      Aadhaar: this.oSession.aadhaar
    }
    let input_jsonin = {
      Input: encryptUsingAES256(jsonin)
    };
    this.feereceiptService.allreceipts(input_jsonin).subscribe(response => {
      if (response == null) {
        this.globalmessage.Show_error('No data found.')
      }
      this.allreceipts = response.data;
    });
  }

  view(mode: string) {

    if(mode == 'PDF'){
      this.downloadloader = true
    }
    this.FeeReceipt = true;
    let jsonin = {
      Receiptid: this.nSelectedReceipt,
      mode: mode
    };
    let input_jsonin = {
      Input: encryptUsingAES256(jsonin)
    };
    this.commonService.Post_json_normal<IRes_downloadsinglereceipt>(downloadstudentreceipt, input_jsonin).subscribe(response => {
      if (response == null) {
        this.globalmessage.Show_error('No data found.')
      }

      if(mode == 'PDF'){
        UDownloadfiles(response.image,response.filename)
        this.downloadloader = false
        return
      }

      this.reciept_img = this.sanitizer.bypassSecurityTrustResourceUrl(`data:image/png;base64, ${Extractguid(response.image)}`);

      // this.ReceiptDetails = response.data;
    });
  }

  onSelectedItemsChange(selectedItems: Ires_allreciepts[]) {

    let filter_noselected: Ires_allreciepts[]
    filter_noselected = selectedItems.filter(
        (receipt_item: Ires_allreciepts) => receipt_item.Receipt_id !== this.signal_selectedId()
    );
    this.nSelectedReceipt = filter_noselected[0]?.Receipt_id ?? undefined
    this.signal_selectedId.set(this.nSelectedReceipt);

    // // this.selectedItemsCount.set(selectedItems.length ?? 0);
    // if (selectedItems['length'] > 1) {
    //   this.globalmessage.Show_error("Please select one record.")
    //   // selectedItems.pop()
    //   return
    // }
    // this.selectednode = selectedItems[0]
    // //
  }

  Get_allreceipts(finyear: number = 0, Collegecode: number = 0, aadhaar: number = 0) {
    let jsonin = {
      CollegeCode: Collegecode,
      Finyear: finyear,
      Aadhaar: aadhaar
    }
    let input_jsonin = {
      Input: encryptUsingAES256(jsonin)
    };
    this.commonService.Post_json_data<Ires_allreciepts[]>(Students_url.allreceipts, input_jsonin).subscribe(response => {
      if (!response || !response.data) {
        return;
      }
      this.allreceipts = response.data;
      this.signal_users.set(this.allreceipts)
      //this.signal_selectedId.set(0);
    });
  }

  getReceipts(selectedId: number | undefined) {
    return this.allreceipts.map((lineitem: Ires_allreciepts) => {
      lineitem._selected = lineitem.Receipt_id === selectedId;
      return {...lineitem};
    });
  }
}
