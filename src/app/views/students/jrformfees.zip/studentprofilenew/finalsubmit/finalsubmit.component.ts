import {Component, OnInit} from "@angular/core";
import {
    ButtonDirective, CardBodyComponent,
    CardComponent,
    ColComponent,
    FormCheckComponent,
    FormCheckInputDirective, FormCheckLabelDirective, FormDirective, RowComponent, SpinnerComponent
} from "@coreui/angular-pro";
import {FormBuilder, FormGroup, ReactiveFormsModule, Validators} from "@angular/forms";
import {encryptUsingAES256} from "../../../../globals/encryptdata";
import {Students_url} from "../../../../globals/global-api";
import {Sessiondata} from "../../../../models/Sessiondata";
import {CommonService} from "../../../../globals/common.service";
import {GlobalMessage} from "../../../../globals/global.message";
import {Router} from "@angular/router";

@Component({
    selector: "app-finalsubmit",
    templateUrl: "./finalsubmit.component.html",
    styleUrls: ["./finalsubmit.component.scss"],
    standalone: true,
    imports: [
        CardComponent,
        ButtonDirective,
        ColComponent,
        FormCheckComponent,
        FormCheckInputDirective,
        FormCheckLabelDirective,
        FormDirective,
        ReactiveFormsModule,
        RowComponent,
        SpinnerComponent,
        CardBodyComponent

    ]
})

export class FinalSubmitComponent implements OnInit {

    finalsubmitForm!: FormGroup;

    oSession!: Sessiondata;
    res_finalsubmitprofile!: boolean;

    finalsubmitloader = false

    constructor(
        private formBuilder : FormBuilder,
        private commonService: CommonService,
        private globalmessage : GlobalMessage,
        private router: Router,
    ) {

    }

    ngOnInit() {
        this.createForm();
    }

    createForm(){
        this.finalsubmitForm = this.formBuilder.group({
            checkOne: ['', Validators.required],
            checktwo: ['', Validators.required],
            checkthree: ['', Validators.required],
        });
    }

    Final_ProfileSubmitted() {
        let jsonin = {
            Finyear: this.oSession.finyear,
            Collegecode: this.oSession.collegecode,
            Aadhaar: this.oSession.aadhaar,
            BatchCode: this.oSession.register_batchcode,
        };
        this.finalsubmitloader = true
        let jsonin_input = {
            Input: encryptUsingAES256(jsonin),
        };
        this.commonService.Post_json_data<boolean>(Students_url.ProfileSubmited, jsonin_input).subscribe((response) => {
            this.res_finalsubmitprofile = response.data
            if (this.res_finalsubmitprofile) {
                this.globalmessage.Show_successmessage("Data uploaded successfully.")
                this.finalsubmitloader = false;
                this.router.navigate(['/dashboard']);
            } else {
                this.globalmessage.Show_error('Please check your data.')
            }
            // this.parentDetailsForm.disable();
            // this.addressDetailsForm.disable();
            // this.nationalitynomineeForm.disable();
            // this.otherDetailsForm.disable();
            // this.reservationdetailForm.disable();
        });
    }

}