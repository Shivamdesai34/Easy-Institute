import {Component, OnInit} from "@angular/core";
import {
    copyData, Ires_droneducation,
    Ires_education,
    Ires_personaldata,
    Res_ProfileResources,
    Student_Educations_new
} from "../../../../models/response";
import {FormArray, FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators} from "@angular/forms";
import {encryptUsingAES256} from "../../../../globals/encryptdata";
import {Common_url, Students_url} from "../../../../globals/global-api";
import {GlobalMessage} from "../../../../globals/global.message";
import {CommonService} from "../../../../globals/common.service";
import {Sessiondata} from "../../../../models/Sessiondata";
import {
    ButtonDirective,
    CalloutComponent,
    ColComponent,
    FormControlDirective, FormFeedbackComponent,
    FormLabelDirective,
    FormSelectDirective, PlaceholderDirective,
    RowComponent
} from "@coreui/angular-pro";
import {FileuploadversiontwoComponent} from "../../fileuploadversiontwo/fileuploadversiontwo.component";
import {ColDef} from "ag-grid-community";
import {StudentprofileService} from "../../studentprofile/studentprofile.service";
import {JsonPipe, NgForOf} from "@angular/common";
import {SessionService} from "../../../../globals/sessionstorage";
import {DataUrl, NgxImageCompressService, UploadResponse} from "ngx-image-compress";
import Swal from "sweetalert2";
import {Router} from "@angular/router";

@Component({
    selector: "app-educationdetails",
    templateUrl: "./educationdetails.component.html",
    styleUrls: ["./educationdetails.component.scss"],
    standalone: true,
    imports: [
        RowComponent,
        ColComponent,
        ReactiveFormsModule,
        FormSelectDirective,
        FormLabelDirective,
        FormControlDirective,
        CalloutComponent,
        JsonPipe,
        NgForOf,
    ],
    providers: [NgxImageCompressService],
})

export class EducationDetailsComponent implements OnInit {

    Education_formGroup!: FormGroup;


    get_personaldetail!: Ires_personaldata;
    selected_document!: Ires_education;
    oSession!: Sessiondata;
    Ires_ProfileResources!: Res_ProfileResources
    student_educations_new!: Student_Educations_new

    state = [''];

    private copyDataSave: any = {} as copyData;


    gridOptions_document: any;
    private gridApi_document: any;
    board: any;
    imagefile: any
    BatchCode: any;

    openpercentage = false
    saveEducationloader = false
    res_educationsubmitted: boolean = true;
    tabfivedisable = true;
    checkbox_percentage: boolean = true;
    SSCSubmit = false;
    copied = false;

    public rowSelection_document: 'single' | 'multiple' = 'single';


    res_droneducation = ['']
    selected_res_droneducation = ''
    res_exampattern= ['']
    selected_res_exampattern = ''

    imgResultBeforeCompress: DataUrl = '';
    imgResultAfterCompress: DataUrl = '';


    constructor(
        private formBuilder: FormBuilder,
        private globalmessage: GlobalMessage,
        private commonService: CommonService,
        private sessionservice: SessionService,
        private imageCompress: NgxImageCompressService,
        private studentprofieservice: StudentprofileService,
        private router: Router,

    ) {
    }

    ngOnInit() {

        this.oSession = new Sessiondata(this.sessionservice);
        this.oSession.Getdatafromstroage();

        this.Education_formGroup = this.formBuilder.group({
            items: this.formBuilder.array([])
        });
        if (this.oSession.isprofilesubmited == 'true') {
            this.tabfivedisable = true
            this.Education_formGroup.disable();
        }
        if (this.oSession.formfeesrecieved == 'NOTPAID') {
            this.router.navigate(['/formfees'])
        }


        this.ProfileResource();

        //temp
        // this.Dron_education();
        // this.Dron_exampattern();
    }

    get itemsArray() {
        return this.Education_formGroup.get('items') as FormArray;
    }


    private createItem(): FormGroup {
        return this.formBuilder.group({
            board: ['', [Validators.required]],
            state: ['', [Validators.required]],
            education_board: ['', [Validators.required]],
            college_name: ['', [Validators.required]],
            datepass: ['', [Validators.required]],
            rollno: ['', [Validators.required]],
            marksheetno: ['', [Validators.required]],
            checkpercentagesgpa: ['', [Validators.required]],

            marksobtained: [''],
            outoff: [''],
            percentage: [''],
            sgpa: [''],


            file: [''],

            // sgpa_percentage: [''],
            // document_type: [''],
            // batchstream: [''],
        });
    }

    // for copy button
    // get formValuesAsString(): string {
    //     const values = this.formGroup.value;
    //     return `board: ${values.board}, state: ${values.state}`;
    // }

    // onCopied(data : any): void {
    //
    //     let copyjson: Student_Educations_new = this.formGroup.value
    //
    //     this.copyDataSave = copyjson
    //
    //     if (data) {
    //         this.copied = true;
    //     }
    //     console.log('copyDataSave',this.copyDataSave)
    // }



    get edf() {
        return this.Education_formGroup.controls;
    }


    defaultColDef: ColDef = {
        flex: 1,
        minWidth: 120,
        filter: true,
        floatingFilter: true,
        sortable: true,
        resizable: true,
    };

    columnDefs_document = [
        {
            field: '', maxWidth: 50, checkboxSelection: true
        },
        {headerName: "Document Name", field: "document_type", resizable: true, maxWidth: 150},
        {headerName: "Uploaded File", flex: 1, field: "uploadedfilename", resizable: true},
        {headerName: "SGPA/Percentage", flex: 1, field: "sgpa_percentage", resizable: true},
    ];

    onGridReady_document(params: any) {
        this.gridApi_document = params.api
    };

    onRowSelected_documentEvent(event: any) {//on checkbox selection
    }

    onSelectiondocument_Changed(event: any) {
        let selected_document = this.gridApi_document.getSelectedRows();
        this.selected_document = selected_document[0]
        this.openpercentage = false
        this.Education_formGroup.patchValue(this.selected_document)
        if (this.selected_document.rowsubmited) {
            this.Education_formGroup.disable();
        } else {
            //Reset control value
            this.Education_formGroup.controls['file'].setValue('')

            this.Education_formGroup.enable();
            if (this.selected_document.document_type == "HSC" || this.selected_document.document_type == "SSC") {
                this.Education_formGroup.controls['checkpercentagesgpa'].setValue("NO")
                this.Education_formGroup.controls['checkpercentagesgpa'].disable()
            }
        }
    }


    EducationSubmit() {
        if (this.get_personaldetail.educationsubmited) {
            this.globalmessage.Show_error('You have already submitted education details.')
            return
        }
        if (this.get_personaldetail.educationsubmited == null) {
            this.globalmessage.Show_error('Please accept the terms and conditions.')
            return
        }
        let jsonin = {
            finyear: this.oSession.finyear,
            college_code: this.oSession.collegecode,
            aadhaar: this.oSession.aadhaar,
        };
        let input_json = {
            Input: encryptUsingAES256(jsonin),
        };
        this.commonService
            .Post_json_data<boolean>(Students_url.IU_educationsubmited, input_json)
            .subscribe((response) => {
                if (response == null) {
                    this.globalmessage.Show_error('Please check your data');
                }
                this.res_educationsubmitted = response.data;
                if (response.data) {
                    this.getPersonalInfo();
                    this.globalmessage.Show_successmessage('Data submitted successfully.')
                }
            });
    }

    getPersonalInfo() {
        if (this.get_personaldetail.educationsubmited) {
            this.tabfivedisable = false;
        }
        this.Check_alleducation_filled();
    }

    Check_alleducation_filled() {
        let lBreak = false
        this.checkbox_percentage = true    //disable
        for (const edu of this.get_personaldetail.education) {
            if (edu.sgpa_percentage <= 0) {
                lBreak = true
                break;
                //this.checkbox_percentage = false
                //break;
            }
        }
        if (!lBreak) {
            this.checkbox_percentage = false
        }
    }

    PercentageCalculater() {
        // let obtainedmarks;
        // let outoff;
        // let percentage;
        // let value;
        // obtainedmarks = parseInt(
        //   this.formGroup.controls['marksobtained'].value
        // );
        // outoff = parseInt(this.formGroup.controls['outoff'].value);
        //
        // if (outoff <= 0) {
        //   return;
        // }
        //
        // if (obtainedmarks <= 0) {
        //   return;
        // }
        //
        // if (obtainedmarks < 100) {
        //   this.globalmessage.Show_error('Obtain marks should be > than 100')
        //   return;
        // }
        //
        //
        // if (obtainedmarks > outoff) {
        //   this.globalmessage.Show_error('Obtain marks should be < than out off marks')
        //
        //   this.formGroup.controls['marksobtained'].setValue('0');
        //   this.formGroup.controls['outoff'].setValue('0');
        //   this.formGroup.controls['percentage'].setValue('0');
        //   return;
        // }
        // percentage = (obtainedmarks / outoff) * 100;
        //
        //
        // this.formGroup.controls['percentage'].setValue(parseFloat(
        //   percentage.toFixed(2))
        // );
        let obtainedmarks = 0;
        let outoff = 0;
        let nper = 0;
        obtainedmarks = this.Education_formGroup.controls['marksobtained'].value
        outoff = this.Education_formGroup.controls['outoff'].value
        // control.value[rownumber].percentage
        if (outoff <= 0) {
            this.Education_formGroup.controls['percentage'].setValue(parseFloat(nper.toFixed(2)))
            return;
        }
        if (obtainedmarks <= 0) {
            this.Education_formGroup.controls['percentage'].setValue(parseFloat(nper.toFixed(2)))
            return;
        }
        /* if (obtainedmarks > 100) {
           this.globalmessage.Show_error('Obtain marks should be < than 100')
           return;
         }*/
        nper = (obtainedmarks / outoff) * 100;
        if (nper > 100) {
            nper = 0
            this.Education_formGroup.controls['percentage'].setValue(parseFloat(nper.toFixed(2)))
            return
        }
        this.Education_formGroup.controls['percentage'].setValue(parseFloat(nper.toFixed(2)))
    }

    getDatafromfileupload(e: any) {
        this.imagefile = e


        console.log(this.Education_formGroup.value)
        console.log(this.imagefile);
        console.log(this.Education_formGroup.valid)
    }

    saveEDUdetails() {
        if (this.imagefile == null) {
            this.globalmessage.Show_error('Please select the document')
            return
        }
        if (this.selected_document.document_type == 'HSC') {
            if (this.Education_formGroup.controls['batchstream'].value == "") {
                this.globalmessage.Show_error('Please select stream for HSC Marksheet.')
                return
            }
        }
        if (this.Education_formGroup.controls['datepass'].value == "") {
            this.globalmessage.Show_error('Please select Date of Passing.')
            return;
        }
        if (this.Education_formGroup.controls['checkpercentagesgpa'].value == "YES") {
            if (this.Education_formGroup.controls['sgpa'].value > 0) {
                if (this.Education_formGroup.controls['sgpa'].value > 10) {
                    this.Education_formGroup.controls['sgpa'].setValue(0)
                    this.globalmessage.Show_error('SGPA should be less than 10.')
                    return;
                }
                this.Education_formGroup.controls['sgpa_percentage'].setValue(this.Education_formGroup.controls['sgpa'].value)
            } else {
                this.globalmessage.Show_error('Enter sgpa ')
                return;
            }
        } else {
            if (this.Education_formGroup.controls['percentage'].value > 0) {
                this.Education_formGroup.controls['sgpa_percentage'].setValue(this.Education_formGroup.controls['percentage'].value)
            } else {
                this.Education_formGroup.controls['sgpa_percentage'].setValue(0)
                this.globalmessage.Show_error('Enter percentage ')
                return;
            }
        }
        this.Education_formGroup.addControl('finyear', new FormControl('', []));
        this.Education_formGroup.controls['finyear'].setValue(this.selected_document.finyear);
        this.Education_formGroup.addControl('college_code', new FormControl('', []));
        this.Education_formGroup.controls['college_code'].setValue(this.selected_document.college_code);
        this.Education_formGroup.addControl('aadhaar', new FormControl('', []));
        this.Education_formGroup.controls['aadhaar'].setValue(this.selected_document.aadhaar);
        this.Education_formGroup.addControl('document_code', new FormControl('', []));
        this.Education_formGroup.controls['document_code'].setValue(this.selected_document.document_code);
        this.Education_formGroup.addControl('uploadedfilename', new FormControl('', []));
        this.Education_formGroup.controls['uploadedfilename'].setValue(this.imagefile.name);
        /*
        if (this.selected_document.document_type == "HSC" || this.selected_document.document_type == "SSC") {

            this.formGroup.controls['uploadedfilename'].setValue(this.imagefile[0].name);

            this.formGroup.controls['checkpercentagesgpa'].setValue("NO")
            this.formGroup.controls['checkpercentagesgpa'].disable()
        }
        */
        this.saveEducationloader = true
        let formdata = new FormData();
        formdata.append('input_form', encryptUsingAES256(this.Education_formGroup.getRawValue()))
        formdata.append('file', this.imagefile)
        this.studentprofieservice
            .IU_StudentEducation(formdata)
            .subscribe((response) => {
                if (response != null) {
                    if (response.data == true) {
                        // this.get_documentdetail();
                        this.globalmessage.Show_message('Education Details Saved.');
                        this.saveEducationloader = false
                        this.Education_formGroup.disable()
                        this.Education_formGroup.controls['file'].setValue('')
                        this.imagefile = null;
                        this.getPersonalInfo();
                    }
                }
            });
    }

    // doubt haii vishal koo niche wale me

    DynamicForm() {
        //https://stackblitz.com/edit/angular-dynamic-form-loop?file=src%2Fapp%2Fapp.component.html
        this.Education_formGroup = this.formBuilder.group({
            participant: this.formBuilder.array([
                // this.getParticipant()
            ])
        });
        const control = <FormArray>this.Education_formGroup.controls['participant'];
        for (const data of this.get_personaldetail.education) {
            control.push(this.getParticipant(data));
        }
        let nLoop = 0
        for (let edu_data of this.get_personaldetail.education) {
            let control = <FormArray>this.Education_formGroup.controls['participant'];
            control.controls[nLoop].patchValue(edu_data)
            nLoop++
        }
    }

    private getParticipant(data: Ires_education) {
        return this.formBuilder.group({
                board: ['', [Validators.required]],
                state: ['', [Validators.required]],
                education_board: ['', [Validators.required]],
                college_name: ['', [Validators.required]],
                datepass: ['', [Validators.required]],
                rollno: ['', [Validators.required]],
                marksheetno: ['', [Validators.required]],
                marksobtained: [''],
                outoff: [''],
                percentage: [''],
                file: [''],
                sgpa: ['', [Validators.required]],
                checkpercentagesgpa: ['', [Validators.required]],
                sgpa_percentage: ['', [Validators.required]],
                document_code: data.document_code,
                document_type: data.document_type,
                document_type_name: data.document_type,
                finyear: data.finyear,
                college_code: data.college_code,
                aadhaar: data.aadhaar,
                // batchstream: this.batchstream,
                // inhouse: ['NO'],
                // hindilinguistic: this.hindilinguistic,
            }
        )
    }



    ProfileResource() {
        this.studentprofieservice
            .ProfileResource("")
            .subscribe((response) => {
                this.Ires_ProfileResources = response.data
                this.state = this.Ires_ProfileResources.State
                this.board = this.Ires_ProfileResources.College_University
            });
    }



    Dron_education(){
        this.commonService.Post_json_data<string[]>(Common_url.dron_education, '').subscribe((response) => {
            this.res_droneducation = response.data

        })
    }

    Dron_exampattern(){
        this.commonService.Post_json_data<string[]>(Common_url.dron_exampattern, '').subscribe((response) => {

            this.res_exampattern = response.data
        })
    }


    change_education(event: Event){
        let selectElement = event.target as HTMLSelectElement;
        this.selected_res_droneducation = selectElement.value;

        console.log(this.selected_res_droneducation);

    }

    change_exampattern(event: Event){
        let selectElement = event.target as HTMLSelectElement;
        this.selected_res_exampattern = selectElement.value;

        this.Dron_marksheetdetails()
    }


    public addEducation(res: any): void {
        const count = Number(res);

        this.itemsArray.clear();

        for (let i = 0; i < count; i++) {
            this.itemsArray.push(this.createItem());
        }
    }

    Dron_marksheetdetails(){

        let jsonin = {
            lasteducation : this.selected_res_droneducation,
            exampattern: this.selected_res_exampattern,
            batch_code: this.oSession.maxbatchcode
        }


        let input_json = {
            Input: encryptUsingAES256(jsonin),
        };


        this.commonService.Post_json_data(Common_url.dron_marksheetdetails, input_json).subscribe((response) => {
            console.log(response);
            // let res = response
            //
            // this.addEducation(res)
        })
    }

}