import {Component} from '@angular/core';
import {CommonModule} from '@angular/common';

import {bootstrapApplication} from '@angular/platform-browser';
import 'zone.js';
import {
    DataUrl,
    NgxImageCaptureModule,
    NgxImageCompressService,
    UploadResponse,
} from 'ngx-image-compress';
import {FormControlDirective} from "@coreui/angular-pro";


@Component({
    selector: 'app-imageCompress',
    templateUrl: './imageCompress.component.html',
    standalone: true,
    imports: [CommonModule, NgxImageCaptureModule, FormControlDirective],
    providers: [NgxImageCompressService],
})


export class ImageCompressComponent {
    // imgResultBeforeCompress: DataUrl = '';
    // imgResultAfterCompress: DataUrl = '';
    //
    // imgResultAfterCompression!: string;

    constructor(private imageCompress: NgxImageCompressService) {
    }
    // compressFile() {
    //     return this.imageCompress
    //         .uploadFile()
    //         .then(({ image, orientation }: UploadResponse) => {
    //             this.imgResultBeforeCompress = image;
    //             console.warn('Size in bytes was:', this.imageCompress.byteCount(image));
    //
    //             this.imageCompress
    //                 .compressFile(image, orientation, 50, 50)
    //                 .then((result: DataUrl) => {
    //                     this.imgResultAfterCompress = result;
    //                     console.warn(
    //                         'Size in bytes is now:',
    //                         this.imageCompress.byteCount(result)
    //                     );
    //                 });
    //         });
    // }





    onFileSelected(event: Event): void {
        const input = event.target as HTMLInputElement;

        if (!input.files || input.files.length === 0) {
            return;
        }

        const file = input.files[0];

        const reader = new FileReader();
        reader.readAsDataURL(file);

        reader.onload = async () => {
            const image = reader.result as DataUrl;

            console.warn(
                'Original size:',
                this.imageCompress.byteCount(image),
                'bytes'
            );

            const compressedImage = await this.imageCompress.compressFile(
                image,
                -1,   // auto orientation
                50,   // quality
                50    // ratio
            );

            console.warn(
                'Compressed size:',
                this.imageCompress.byteCount(compressedImage),
                'bytes'
            );
        };
    }


    dataUrlToFile(dataUrl: string, fileName: string): File {
        const arr = dataUrl.split(',');
        const mime = arr[0].match(/:(.*?);/)![1];
        const bstr = atob(arr[1]);
        let n = bstr.length;
        const u8arr = new Uint8Array(n);

        while (n--) {
            u8arr[n] = bstr.charCodeAt(n);
        }

        return new File([u8arr], fileName, { type: mime });
    }


}

