import {Component, OnInit, Renderer2, ViewEncapsulation} from '@angular/core';
import {ReactiveFormsModule, UntypedFormBuilder, UntypedFormGroup, Validators,} from '@angular/forms';
import {ActivatedRoute, Router, RouterLink} from '@angular/router';
import {FeesService} from './fees.service';
import {BilldeskPay} from './../../../../assets/javascript/billdesk';
import {GlobalMessage} from "../../../globals/global.message";
import {
  AdmissionQuotasubjectGroups,
  Fin_year_new,
  Ires_ApprovedCourse,
  Ires_installments,
  Ires_Reciept,
  Paymentterms,
  Student_Profile, Student_ProfileStatus, Subjects_group_h
} from "../../../models/response";
import {CommonService} from "../../../globals/common.service";
import {Common_url, Students_url,} from "../../../globals/global-api";
import {Ireq_approvedcourse, Ireq_checkadmission, Ireq_StudentProfileStatus_url} from "./fees.requestmodel";
import {SessionService} from "../../../globals/sessionstorage";
import {Sessiondata} from "../../../models/Sessiondata";
import {encryptUsingAES256} from "../../../globals/encryptdata";
import {
  ButtonDirective,
  CardBodyComponent,
  CardComponent,
  CardHeaderComponent,
  ColComponent,
  FormCheckComponent,
  FormCheckInputDirective, FormCheckLabelDirective, FormControlDirective, FormLabelDirective, FormSelectDirective,
  RowComponent,
  SpinnerComponent, TableDirective
} from "@coreui/angular-pro";
import {IconComponent} from "@coreui/icons-angular";


@Component({
  templateUrl: './fees.component.html',
  styleUrls: ['./fees.component.scss'],
  encapsulation: ViewEncapsulation.None,
  imports: [
    ReactiveFormsModule,
    ColComponent,
    RowComponent,
    FormCheckComponent,
    SpinnerComponent,
    CardComponent,
    RouterLink,
    IconComponent,
    CardHeaderComponent,
    CardBodyComponent,
    ButtonDirective,
    FormCheckInputDirective,
    TableDirective,
    FormCheckLabelDirective,
    FormLabelDirective,
    FormSelectDirective,
    FormControlDirective
  ],
  standalone: true
})
export class FeesComponent implements OnInit {
  Rjcollegeemail: string = "rjcollege@rjcollege.edu.in"
  FeesPaymentForm!: UntypedFormGroup;
  PaymentForm!: UntypedFormGroup;
  res_Reciept = {} as Ires_Reciept
  TermCode: any;
  InstallmentID: any;
  Quota_status: any;
  QuotaStatus:  AdmissionQuotasubjectGroups[] = [];
  feesPaid: any;
  FullName: any;
  Mobile: any;
  BatchName: any;
  Email: any;
  InstallmentName: any;

  Demoversion: boolean = false;
  submitted = false;
  data: any;
  FeeStructure: any;
  selectedBatchCode: any = '';
  selectedSubjectGroupId: any = '';
  selectedSubjectGroupCode: any = '';
  ShowDeclaration = false;
  selectedObject: any;
  Batch: any;
  batchSubjects: Subjects_group_h[]=[];
  SubjectGroups: any;
  SubjectGroupID: any;
  res: any;
  index: any;
  Installments: any;
  Header: any;
  Lineitem: any;
  Amount: any;
  FeeReceipt = false;
  FeeModal = true;
  changeState = true;
  billdeskRequestMsg: string='';
  firstSubjectGroupID: any;
  firstBatchCode: any;
  firstSelectedBatch: any;
  firstSubjectGroupName: any;
  firstSubjectGroupCode: any;
  ActiveFinyear:number=0
  //loader

  feesloader = false;
  paymentloader = false;
  billdeskquerymsg!: {
    finyear: number;
    collegecode: number;
    aadhaar: number;
    batchcode: number;
    CustomerID: string;
  };
  selectedBatchName: any;
  SubjectGroupCode: any;
  TotalAmount: number = 0;
  firstInstallmenttext = false;
  InstallmentTerm = '';
  paymentterms!: Paymentterms;
  aApprovedCourses!: Ires_ApprovedCourse[];
  selected_batch!: Ires_ApprovedCourse
  profile_res = {} as Student_ProfileStatus;
  selected_profile_res = {} as Student_Profile
  aInstallment_res!: Ires_installments;
  oSession!: Sessiondata;

  constructor(
    private router: Router, private commonService: CommonService,
    private feesService: FeesService, private sessionservice: SessionService,
    private formBuilder: UntypedFormBuilder,
    private renderer: Renderer2,
    private route: ActivatedRoute,
    private globalmessage: GlobalMessage
  ) {
    // let xDomain = myGlobals.Domainname.toUpperCase();
    // if (xDomain.search('LOCALHOST') != -1) {
    //     this.Demoversion = true;
    // }
    // if (xDomain.search('DEMO') != -1) {
    //     this.Demoversion = true;
    // }
  }

  AadharSession = parseInt(sessionStorage.getItem('Aadhaar')!);
  FinyearSession = parseInt(sessionStorage.getItem('Finyear')!);
  // BatchCode = parseInt(sessionStorage.getItem('BatchCode')!);
  TokenSession = sessionStorage.getItem('token');

  // StudentType = sessionStorage.getItem('StudentType');
  renderExternalScript(src: string): HTMLScriptElement {
    const script = document.createElement('script');
    script.type = 'text/javascript';
    script.src = src;
    script.async = true;
    script.defer = true;
    this.renderer.appendChild(document.body, script);
    return script;
  }

  get f() {
    return this.FeesPaymentForm.controls;
  }

  ngOnInit() {
    this.oSession = new Sessiondata(this.sessionservice)
    this.oSession.Getdatafromstroage();
    /*
    if (this.oSession.studenttype == 'ATKT') {
        this.studentactivefinyear();
        this.checkAdmission();
        this.StudentProfileStatus();
    } else if (this.oSession.studenttype == 'OUTSIDE') {
        this.studentactivefinyear();
        this.checkAdmission();
        this.StudentProfileStatus();
    } else if (this.oSession.studenttype == 'NONE') {
        this.CheckOutstanding();
    }
    // this.CheckOutstanding();

     */
    // https://services.billdesk.com/checkout-widget/src/app.bundle.js
    this.renderExternalScript(
      'https://pgi.billdesk.com/payments-checkout-widget/src/app.bundle.js'
    ).onload = () => {
    };
    this.CreateForm()
    this.StudentApprovedCourses();
  }

  CreateForm() {
    this.FeesPaymentForm = this.formBuilder.group({
      batch: ['', Validators.required],
      batchSubjects: ['', Validators.required],
      installment: ['', Validators.required],
      checkbox: ['', Validators.required],
    });
    if (this.InstallmentID == 1) {
      this.PaymentForm = this.formBuilder.group({
        checkdec: ['', Validators.required],
        termsandconditions: ['', Validators.required],
      });
    } else {
      this.PaymentForm = this.formBuilder.group({
        termsandconditions: ['', Validators.required],
        // checkdec: ['', Validators.required],
      });
    }
  }

  studentactivefinyear() {
    this.feesService.studentactivefinyear("").subscribe((response) => {
      if (response == null) {
        return;
      }
      this.ActiveFinyear=response
      this.FinyearSession = response;
    });
  }

  InstallmentValidation() {
    this.studentactivefinyear();
    // if (this.oSession.finyear <= 0) {
    //     this.globalmessage.Show_message('Fincial year not found');
    //     return;
    // }
    this.feesloader = true
    let jsonin = {
      collegecode: this.oSession.collegecode,
      finyear: this.oSession.finyear,
      batchcode: parseInt(this.selected_batch.Batch_code),
      aadhaar: this.oSession.aadhaar,
      termcode: this.TermCode,
      installment: this.InstallmentID,
    };
    let input_jsonin = {
      Input: encryptUsingAES256(jsonin)
    };
    this.feesService.InstallmentValidation(input_jsonin).subscribe((response) => {
      this.feesloader = false
      if (response.data == false) {
        this.globalmessage.Show_message(response.message);
        this.resetAll();
      } else {
        // this.FinyearSession = this.data.finyear;
        this.paymentShowDetails();
        this.CheckSubjectGroupQuota();
      }
      // this.showFeesAmount(this.FeeStructure);
    });
  }

  //new 13-07-2022
  StudentApprovedCourses() {
    let jsonin: Ireq_approvedcourse = {
      Finyear: this.oSession.finyear,
      Collegecode: this.oSession.collegecode,
      Aadhaar: this.oSession.aadhaar,
    };
    let input_jsonin = {
      Input: encryptUsingAES256(jsonin)
    };
    this.feesService.StudentApprovedCourses(input_jsonin).subscribe((response) => {
      this.aApprovedCourses = response.data
      if (this.aApprovedCourses == null) {
        this.globalmessage.Show_message('You have not approved in any course')
        return
      }
    });
  }

  formFees: any;

  FormFeesPaid() {
    // if (this.FinyearSession <= 0) {
    //     this.FinyearSession = parseInt(sessionStorage.getItem('Finyear')!);
    // }
    let jsonin = {
      Finyear: this.oSession.finyear,
      Collegecode: this.oSession.collegecode,
      BatchCode: this.oSession.batchcode,
      Aadhaar: this.oSession.aadhaar,
    };
    let input_jsonin = {
      Input: encryptUsingAES256(jsonin)
    };
    this.commonService.Post_json_data(Students_url.FormFeesPaid_URL, input_jsonin).subscribe((response) => {
      this.res = response;
      if (this.res.data == true) {
        this.checkAdmission();
        this.StudentProfileStatus();
      }
      if (this.res.data == false) {
        //ShiVAm
        //   this.router.navigate['/dashboard'];
        this.globalmessage.Show_message('Please pay your form fees  xxx!')
      }
    });
  }

  print() {
    // tslint:disable-next-line:no-unused-expression
    window && window.print();
  }

//ShiVam
  openYesNoDialog(msg: any) {
    this.globalmessage.Show_message(msg)
    //     // negative: 'No',
    //     // neutral: 'Not sure'
    //
    //   .then((response: any) => {}, () => {
    //     }
    //   );
  }

  checkAdmission() {
    //Prakash 13/4/2024
    // if (this.oSession.finyear! <= 0) {
    //     this.openYesNoDialog('Financial year not found!');
    //     this.oSession.finyear = parseInt(this.oSession.finyear);
    // }
    // if (this.oSession.aadhaar! <= 0) {
    //     this.openYesNoDialog('aadhaar  not found!');
    // }
    let jsonin: Ireq_checkadmission = {
      Collegecode: this.oSession.collegecode,
      Finyear: this.oSession.finyear,
      Aadhaar: this.oSession.aadhaar,
    };
    let input_jsonin = {
      Input: encryptUsingAES256(jsonin)
    };
    this.feesService.CheckAdmission_URL(input_jsonin).subscribe((response) => {
      this.selectedBatchCode = response.data.batch_code;
      this.selectedSubjectGroupId = response.data.subject_group_id;
      this.selectedSubjectGroupCode = response.data.subject_group_code;
      this.selectedBatchName = response.data.batch_name;
      this.feesPaid = response.data.feespaid;
      this.oSession.finyear = this.oSession.finyear;
      this.StudentApprovedCourses();
    });
  }

  StudentProfileStatus() {
    let jsonin: Ireq_StudentProfileStatus_url = {
      Finyear: this.oSession.finyear,
      Collegecode: this.oSession.collegecode,
      Aadhaar: this.oSession.aadhaar,
      studenttype: this.oSession.studenttype,
      webportname: 'STUDENTS',
    };
    let input_jsonin = {
      Input: encryptUsingAES256(jsonin)
    };
    this.commonService.Post_json_data<Student_ProfileStatus>(Students_url.StudentProfileStatus_url, input_jsonin).subscribe((response) => {
      this.profile_res = response.data

      if (this.profile_res.Profile.Aadhaar == 0) {
        // Prakash
        if (this.oSession.studenttype == 'ATKT') {
          this.router.navigate(['/Fillprofile']);
        }
        if (this.oSession.studenttype == 'OUTSIDE') {
          this.router.navigate(['/Fillprofile']);
        }
        if (this.oSession.studenttype == 'NONE') {
          this.router.navigate(['/fillprofile']);
        }
      } else if (this.profile_res.Education == false) {
        if (this.oSession.studenttype == 'ATKT') {
          this.router.navigate(['/Fillprofile']);
        }
        if (this.oSession.studenttype == 'OUTSIDE') {
          this.router.navigate(['/Fillprofile']);
        }
        if (this.oSession.studenttype == 'NONE') {
          // this.router.navigate(["/students/fillprofile"])
        }
      } else if (this.profile_res.Reservation.Aadhaar == 0) {
        if (this.oSession.studenttype == 'ATKT') {
          this.router.navigate(['/Fillprofile']);
        }
        if (this.oSession.studenttype == 'OUTSIDE') {
          this.router.navigate(['/Fillprofile']);
        }
        if (this.oSession.studenttype == 'NONE') {
          this.router.navigate(['/fillprofile']);
        }
      }
    });
  }

  onBatchSelected(event: any) {
    if (this.selected_batch != null) {
      this.ShowInstallmentDetails();
    }
  }

  onSubjectSelect(event: any) {
    //this.firstSubjectGroupCode = event.Subject_group_code;
    this.firstSubjectGroupName = event.Subject_group_name;
  }

  SelectBatchSubjects() {
    if (this.selectedBatchCode != null || this.selectedBatchCode != undefined) {
      let jsonin = {
        BatchCode: this.selectedBatchCode,
      };
      this.commonService.Post_json_data<Subjects_group_h[]>(Common_url.BatchSubjects, jsonin).subscribe((response) => {
        this.batchSubjects = response.data;
        for (var key in this.batchSubjects) {
          if (this.batchSubjects.hasOwnProperty(key)) {
            if (
              this.batchSubjects[key].Subject_group_code ==
              this.selectedSubjectGroupCode
            ) {
              this.selectedObject = this.batchSubjects[key].Subject_group_code;
              this.SubjectGroups = this.batchSubjects[key].Subject_group_name;
            }
          }
        }
        // this.selectedObject = this.batchSubjects[0].Subject_group_code
        // this.SubjectGroups = this.batchSubjects[0].Subject_group_name
        if (this.selected_batch != null) {
          this.ShowInstallmentDetails();
        }
      });
    } else {
      this.openYesNoDialog('Select Batch');
      // alert("Select Batch")
    }
  }

  onGroupSelected(event: any) {
    // this.SubjectGroups = event.Subject_group_name
    // this.SubjectGroupID = event.Subject_group_id;
    // this.Quota_status = event.Quota_status;
    for (var key in this.batchSubjects) {
      if (this.batchSubjects.hasOwnProperty(key)) {
        if (this.batchSubjects[key].Subject_group_code == event) {
          this.SubjectGroups = this.batchSubjects[key].Subject_group_name;
          this.SubjectGroupID = this.batchSubjects[key].Subject_group_id;
          this.SubjectGroupCode = this.batchSubjects[key].Subject_group_code;
          this.Quota_status = this.batchSubjects[key].Quota_status;
        }
      }
    }
  }

  ShowInstallmentDetails() {
    this.submitted = true;
    let jsonin = {
      CollegeCode: this.oSession.collegecode,
      Finyear: this.oSession.finyear,
      BatchCode: parseInt(this.selected_batch.Batch_code),
      Aadhaar: this.oSession.aadhaar,
    }
    let input_jsonin = {
      Input: encryptUsingAES256(jsonin)
    };
    this.commonService.Post_json_data<Ires_installments>(Students_url.studentfeesinstallment_new,input_jsonin)
      .subscribe((response) => {
        this.aInstallment_res = response.data;

        if (this.aInstallment_res.Message == "") {
        } else {
          this.globalmessage.Show_error(this.aInstallment_res.Message);
          return;
        }
        if (this.aInstallment_res.InstallmentAlreadyPaid == true) {
          this.globalmessage.Show_message('All Installments are Paid!');
          return;
        }
        if (this.aInstallment_res.Installments == null) {
          this.globalmessage.Show_error('No Installments Found!');
          return;
        }
      });
  }

  CheckSubjectGroupQuota() {
    let jsonin = {
      collegecode: this.oSession.collegecode,
      finyear: this.oSession.finyear,
      batchcode: parseInt(this.selected_batch.Batch_code),
      subjectgroupid: parseInt(this.selected_batch.Subject_group_id),
      subject_group_code: this.selected_batch.Subject_group_code,
      quota_status: 'XXXX',
    };
    let input_jsonin = {
      Input: encryptUsingAES256(jsonin)
    };
    this.commonService
        .Post_json_data<AdmissionQuotasubjectGroups>(Students_url.CheckSubjectGroupQuota,input_jsonin).subscribe((response) => {

      if (response.data == null) {
        this.globalmessage.Show_error('No data found')
        return
      }

      let QuotaStatus: AdmissionQuotasubjectGroups = {} as AdmissionQuotasubjectGroups;
      QuotaStatus = response.data
      if (QuotaStatus.Quota_status == 'CLOSE') {
        this.globalmessage.Show_message('Quota Closed! Select Different Group Code.');
        this.changeState = false;
      }else {
        this.showReceipt()
      }
      //     this.QuotaStatus = response.data;
      //
      // if (this.feesPaid <= 0) {
      //   if (this.QuotaStatus[0].Quota_status != 'OPEN') {
      //     this.globalmessage.Show_message('Quota Closed! Select Different Group Code.');
      //     this.changeState = false;
      //   } else {
      //     this.showReceipt();
      //   }
      // } else {
      //   this.showReceipt();
      //   // this.openYesNoDialog("Subject Group cannot be changed!")
      // }
    });
  }

  showFeesAmount(FeeStructure: any) {
    this.Amount = FeeStructure.Header.Amount;
    this.TermCode = FeeStructure.Header.Term_code;
    this.FullName = FeeStructure.Header.FullName;
    this.BatchName = FeeStructure.Header.BatchName;
    this.Mobile = FeeStructure.Header.Mobile;
    this.Email = FeeStructure.Header.Emailid;
    this.InstallmentID = FeeStructure.Header.Installmentid;
    this.InstallmentName = FeeStructure.Header.Installment;
    this.Lineitem = FeeStructure.Lineitem;

    const ShowDeclaration_ctrl = this.FeesPaymentForm.get('checkbox');
    const validators = [Validators.required];
    if (this.InstallmentID == 1) {
      this.InstallmentTerm = this.aInstallment_res.Terms
      this.ShowDeclaration = true;
      this.firstInstallmenttext = true;
      ShowDeclaration_ctrl!.addValidators(validators);
      // this.FeesPaymentForm = this.formBuilder.group({
      //     checkbox: ['', Validators.required],
      // });
    } else {
      this.ShowDeclaration = false;
      ShowDeclaration_ctrl!.removeValidators(validators);
      // this.FeesPaymentForm = this.formBuilder.group({
      //     checkbox: [''],
      // });
    }
    this.TotalAmount = this.Amount
    ShowDeclaration_ctrl!.updateValueAndValidity();
  }

  paymentShowDetails() {
    this.feesService.paymentterms("").subscribe((response) => {
      if (response == null) {
        return;
      }
      this.paymentterms = response.data;
    });
  }

  showReceipt() {
    // this.CheckSubjectGroupQuota()
    // if(this.QuotaStatus == "OPEN"){
    //   this.openYesNoDialog("Quota Closed! Select Different Group Code.")
    //   this.changeState = false;
    // }
    // else{
    //   this.submitted = true;
    //   this.FeeReceipt = true;
    //   this.FeeModal = false;
    //   this.IU_Receipt();
    // }
    this.submitted = true;
    this.FeeReceipt = true;
    this.FeeModal = false;
    this.IU_Receipt();
  }

  ChangeInstallment() {
    this.FeeModal = true;
    this.FeeReceipt = false;
    this.FeeStructure = '';
    this.Amount = '';
    this.resetAll();
  }

  resetAll() {
    let currentUrl = this.router.url;
    this.router.navigateByUrl('/', {skipLocationChange: true}).then(() => {
      this.router.navigate([currentUrl]);
      // if (this.StudentType == "ATKT") {
      //   this.router.navigate(["/Fees"]);
      // }
      // else if (this.StudentType == "OUTSIDE") {
      //   this.router.navigate(["/Fees"]);
      // }
      // else if (this.StudentType == "NONE") {
      //   this.router.navigate(["/students/fees"]);
      // }
    });
  }

  IU_Receipt() {
    let jsonin = {
      finyear: this.oSession.finyear,
      college_code: this.oSession.collegecode,
      aadhaar: this.oSession.aadhaar,
      batch_code: parseInt(this.selected_batch.Batch_code),
      term_code: this.TermCode,
      installment: this.InstallmentID,
      existing_subject_group_id: parseInt(this.selected_batch.Subject_group_id),
      paid_subject_group_id: parseInt(this.selected_batch.Subject_group_id),
      existing_subject_group_code: this.selected_batch.Subject_group_code,
      paid_subject_group_code: this.selected_batch.Subject_group_code,
      termmessage: this.InstallmentTerm
    };
    let input_jsonin = {
      Input: encryptUsingAES256(jsonin)
    };
    this.commonService.Post_json_data<Ires_Reciept>(Students_url.IU_receipt, input_jsonin).subscribe((response) => {
      this.res_Reciept = response.data
    });
  }

  // BillDeskcheckSumQuery() {
  //   this.billdeskquerymsg = {
  //     "finyear": this.FinyearSession,
  //     "collegecode": 1,
  //     "aadhaar": this.AadharSession,
  //     "batchcode": parseInt(this.selectedBatchCode),
  //     "CustomerID": String(this.ReceiptNO)
  //   }
  //   this.feesService.BillDeskcheckSumQuery(this.billdeskquerymsg).subscribe(response => {
  //   })
  // }
  FeesPayment() {
    this.paymentloader = true
    let nTranscationamount = "";
    // if (this.oSession.demo == 'true') {
    //     nTranscationamount = '1';
    // } else {
    //     nTranscationamount = String(this.Amount);
    // }
    if (this.PaymentForm.invalid) {
      this.openYesNoDialog(
        'Please Accept Terms & Conditions to Proceed to Payment!'
      );
    } else {
      let jsonin = {
        collegecode: this.oSession.collegecode,
        finyear: this.oSession.finyear,
        batchcode: parseInt(this.selected_batch.Batch_code),
        aadhaar: this.oSession.aadhaar,
        termcode: this.TermCode,
        MerchantID: '',
        CustomerID: String(this.res_Reciept.ReceiptNo),
        Filler1: 'NA',
        TxnAmount: String(this.Amount),
        //TxnAmount: String(this.Amount),
        //  "TxnAmount":"1",
        BankID: 'NA',
        Filler2: 'NA',
        Filler3: 'NA',
        CurrencyType: 'INR',
        ItemCode: 'NA',
        TypeField1: 'R',
        SecurityID: '',
        Filler4: 'NA',
        Filler5: 'NA',
        TypeField2: 'F',
        AdditionalInfo1: String(this.oSession.finyear),
        // "AdditionalInfo2": String(this.CollegeCodeSession),
        AdditionalInfo2: '',
        AdditionalInfo3: String(this.selected_batch.Batch_code),
        AdditionalInfo4: String(this.oSession.aadhaar),
        AdditionalInfo5: String(this.TermCode),
        AdditionalInfo6: String(this.InstallmentID),
        AdditionalInfo7: String(this.res_Reciept.ReceiptID),
        TypeField3: 'NA',
      };
      let input_jsonin = {
        Input: encryptUsingAES256(jsonin)
      };
      if (this.res_Reciept.ReceiptID > 0) {
        this.commonService
          .Post_json_data<string>(Students_url.BillDeskcheckSum,input_jsonin)
          .subscribe((response) => {
            this.paymentloader = false
            this.billdeskRequestMsg = response.data;
            if (this.billdeskRequestMsg != null) {
              BilldeskPay(this.billdeskRequestMsg, "", "");
              // let headers = new HttpHeaders()
              // let hostdata = headers.get("Host")
            }
          });
      }
    }
  }
}
