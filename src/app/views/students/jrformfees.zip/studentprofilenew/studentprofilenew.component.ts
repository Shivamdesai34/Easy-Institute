import {Component, HostListener, OnInit, signal, ViewChild} from "@angular/core";
import {
    BadgeComponent,
    ButtonDirective,
    CardBodyComponent,
    CardComponent,
    CardHeaderComponent,
    ColComponent,
    FormControlDirective,
    FormDirective,
    FormLabelDirective,
    FormSelectDirective,
    RowComponent,
    SpinnerComponent,
    StepperComponent,
    StepperStepComponent
} from "@coreui/angular-pro";
import {FormBuilder, FormControl, FormGroup, ReactiveFormsModule, Validators} from "@angular/forms";
import {encryptUsingAES256} from "../../../globals/encryptdata";
import {GlobalMessage} from "../../../globals/global.message";
import {Sessiondata} from "../../../models/Sessiondata";
import {SessionService} from "../../../globals/sessionstorage";
import {StudentprofileService} from "../studentprofile/studentprofile.service";
import {Ires_education, Ires_personaldata, Ires_personalinfo, Res_ProfileResources} from "../../../models/response";
import {EducationDetailsComponent} from "./educationdetails/educationdetails.component";
import {Uppercase} from "../../../uppercase";
import {FinalSubmitComponent} from "./finalsubmit/finalsubmit.component";
import {ReservationDetailsComponent} from "./reservationdetails/reservationdetails.component";
import {PersonalDetailsComponent} from "./personaldetails/personaldetail.component";
import {JsonPipe, NgTemplateOutlet} from "@angular/common";
import {CommonService} from "../../../globals/common.service";
import {Students_url} from "../../../globals/global-api";
import * as myGlobals from "../../../globals/global-variable";
import {ImageCompressComponent} from "./imageCompress/imageCompress.component";
import {Router} from "@angular/router";

@Component({
    templateUrl: './studentprofilenew.component.html',
    styleUrls: ['./studentprofilenew.component.scss'],
    standalone: true,
    imports: [
        ButtonDirective,
        ColComponent,
        FormDirective,
        FormSelectDirective,
        ReactiveFormsModule,
        RowComponent,
        SpinnerComponent,
        CardComponent,
        CardBodyComponent,
        CardHeaderComponent,
        EducationDetailsComponent,
        Uppercase,
        FormLabelDirective,
        FormControlDirective,
        StepperComponent,
        StepperStepComponent,
        FinalSubmitComponent,
        ReservationDetailsComponent,
        PersonalDetailsComponent,
        BadgeComponent,
        JsonPipe,
        NgTemplateOutlet,
        ImageCompressComponent,
    ],
})

export class StudentProfileNewComponent implements OnInit {

    @ViewChild('step2',{static: false}) step2_ref : any;
    // public stepperLayout: 'horizontal' | 'vertical' = 'horizontal';


    studentDetailsForm!: FormGroup;
    oSession!: Sessiondata;
    Ires_ProfileResources!: Res_ProfileResources
    ires_personalinfo!: Ires_personalinfo
    get_personaldetail!: Ires_personaldata;

    selctgen!: any;
    select_hindiling!: any;
    select_inhouse!: any;
    board: any;

    gender = [''];
    religion = [''];
    mother_tongue = [''];
    martial_status = [''];
    relation = [''];
    occupation = [''];
    annual_income = [''];
    nominee_relation = [''];
    location_area = [''];
    country = [''];
    state = [''];
    district = [''];
    bloodgroup = [''];
    reservation = [''];
    category = [''];
    specially_abled = [''];
    activity = [''];
    participation_level = [''];
    secured_rank = [''];

    savepersonalloader = false;
    IUStudentDetails: boolean = false;
    submitted = false;
    tabfivedisable = true;

    constructor(
        private formBuilder: FormBuilder,
        private globalmessage: GlobalMessage,
        private sessionservice: SessionService,
        private commonService : CommonService,
        private studentprofieservice: StudentprofileService,
        private router: Router,

    ) {
    }

    ngOnInit() {

        this.oSession = new Sessiondata(this.sessionservice);
        this.oSession.Getdatafromstroage();
        this.CreateForm();

        // this.setLayout(window.innerWidth);
        this.ProfileResource();

    }

    CreateForm() {
        this.studentDetailsForm = this.formBuilder.group({
            firstname: ['', Validators.maxLength(30)],
            lastname: ['', Validators.maxLength(30)],
            fathername: ['', Validators.required, Validators.maxLength(30)],
            mothername: ['', Validators.required, Validators.maxLength(30)],
            gender: ['', Validators.required],
            dob: ['', Validators.required],
            placeofbirth: ['', Validators.maxLength(30)],
            religion: [''],
            mothertongue: [''],
            marital_status: [''],
            inhouse: ['', Validators.required],
            hindilinguistic: ['', Validators.required],
            applicant_name_on_marksheet: ['', Validators.required, Validators.maxLength(60)],
            name_change_after_passing: [''],
        });

        if (this.oSession.isprofilesubmited == 'true') {
            this.tabfivedisable = true
            this.studentDetailsForm.disable();
        }
        if (this.oSession.formfeesrecieved == 'NOTPAID') {
            this.router.navigate(['/formfees'])
        }

        this.personalInfo()

    }

    // @HostListener('window:resize', ['$event'])
    // onResize(event: any) {
    //     this.setLayout(event.target.innerWidth);
    // }
    //
    // private setLayout(width: number): void {
    //     // Define your breakpoint (e.g., 768px for a typical mobile/desktop split)
    //     const breakpoint = 768;
    //     if (width < breakpoint) {
    //         this.stepperLayout = 'vertical'; // Vertical on mobile
    //     } else {
    //         this.stepperLayout = 'horizontal'; // Horizontal on desktop
    //     }
    // }

    get sdf() {
        return this.studentDetailsForm.controls;
    }

    onSavedetails() {
        if (this.selctgen == null) {
            this.globalmessage.Show_error('Please select gender.')
            return
        }
        this.studentDetailsForm.addControl('finyear', new FormControl('', []));
        this.studentDetailsForm.controls['finyear'].setValue(this.oSession.finyear);
        this.studentDetailsForm.addControl('college_code', new FormControl('', []));
        this.studentDetailsForm.controls['college_code'].setValue(
            this.oSession.collegecode
        );
        this.studentDetailsForm.addControl('aadhaar', new FormControl('', []));
        this.studentDetailsForm.controls['aadhaar'].setValue(this.oSession.aadhaar);
        this.savepersonalloader = true
        let input_json = {
            Input: encryptUsingAES256(this.studentDetailsForm.value),
        };
        this.studentprofieservice
            .IU_Personalinfo(input_json)
            .subscribe((response) => {
                if (response == null) {
                    this.globalmessage.Show_error('Please check your details');
                }
                this.IUStudentDetails = response;
                this.globalmessage.Show_successmessage('Data updated successfully')
                this.savepersonalloader = false
                // this.personalInfo();
            });
    }

    ProfileResource() {
        this.studentprofieservice
            .ProfileResource("")
            .subscribe((response) => {
                this.Ires_ProfileResources = response.data
                this.relation = this.Ires_ProfileResources.Relation_Type
                this.occupation = this.Ires_ProfileResources.occupation_guardian
                this.annual_income = this.Ires_ProfileResources.annual_income
                this.location_area = this.Ires_ProfileResources.Location_Area
                this.country = this.Ires_ProfileResources.country
                this.state = this.Ires_ProfileResources.State
                this.district = this.Ires_ProfileResources.district
                this.bloodgroup = this.Ires_ProfileResources.BloodGroup
                this.nominee_relation = this.Ires_ProfileResources.Nominee_Relation
                this.gender = this.Ires_ProfileResources.sex
                this.religion = this.Ires_ProfileResources.Religion
                this.mother_tongue = this.Ires_ProfileResources.mother_tongue
                this.martial_status = this.Ires_ProfileResources.Marital_Status
                this.reservation = this.Ires_ProfileResources.parallel_horizontal_reservation
                this.category = this.Ires_ProfileResources.category.slice(1)
                this.specially_abled = this.Ires_ProfileResources.specially_abled
                this.activity = this.Ires_ProfileResources.activity
                this.participation_level = this.Ires_ProfileResources.participation_level
                this.secured_rank = this.Ires_ProfileResources.secured_rank
                this.board = this.Ires_ProfileResources.College_University
            });
    }

    readonly stepperForm: FormGroup = new FormGroup({
        step_0: new FormGroup({

            Profilepictform: this.formBuilder.group({}),
            parentDetailsForm: this.formBuilder.group({}),
            addressDetailsForm: this.formBuilder.group({}),
            nationalitynomineeForm: this.formBuilder.group({}),
            otherDetailsForm: this.formBuilder.group({}),
            checkfinalSubmit: this.formBuilder.group({}),

        }),
        step_1: new FormGroup({
            reservationdetailForm: this.formBuilder.group({}),
        }),
        step_2: new FormGroup({
            Education_formGroup: this.formBuilder.group({}),
        }),
        step_3: new FormGroup({
            finalsubmitForm: this.formBuilder.group({})
        }),
        step_4: new FormGroup({

        })
    });


    readonly formGroups = Object.values(this.stepperForm.controls);
    readonly group_0 = this.stepperForm.get('step_0') as FormGroup;
    readonly group_1 = this.stepperForm.get('step_1') as FormGroup;
    readonly group_2 = this.stepperForm.get('step_2') as FormGroup;
    readonly group_3 = this.stepperForm.get('step_3') as FormGroup;
    readonly group_4 = this.stepperForm.get('step_4') as FormGroup;

    readonly finished = signal(false);
    readonly currentStep = signal(0);

    // currentStep: number = 0;

    handleReset() {
        this.stepperForm.reset();
        this.finished.set(false);
    }

    handleFinish(finish: boolean) {
        if (!finish) {
            return false;
        }
        const valid = this.currentFormGroupValid(this.currentStep());
        if (!valid) {
            // return false;
        }
        this.finished.set(finish);
        return true;
    }

    currentFormGroupValid(step: number) {
        const currentGroup = `group_${step}` as keyof StudentProfileNewComponent;
        const currentFormGroup = this[currentGroup] as FormGroup;
        currentFormGroup.markAllAsTouched();
        return currentFormGroup?.valid;
    }

    handleNext(stepper: StepperComponent) {
        const valid = this.currentFormGroupValid(this.currentStep());
        if (!valid) {
            // return false;
        }
        stepper.next();
    }


    // changeStepper(stepper: StepperComponent){
    //
    //     let valid = stepper.activeStepIndex()
    //
    //     if(valid == 0){
    //         this.currentStep = 0
    //     }
    //
    //     if(valid == 1){
    //         this.currentStep = 1
    //     }
    //
    //     if(valid == 2){
    //         this.currentStep = 2
    //     }
    //
    //     if(valid == 3){
    //         this.currentStep = 2
    //     }
    // }

    // changeStep(index_step: StepperComponent){
    //
    //     let value= index_step.activeStepIndex()
    //
    //     // if (value == 1){
    //     //     this.reser
    //     // }
    //
    //     console.log(value)
    // }

    // PersonalInfo API Calling
        personalInfo(){

        let nBatchcode = 0

        if (this.oSession.currentformfeesbatchcode! <= 0) {
            nBatchcode = this.oSession.maxbatchcode!
        } else {
            nBatchcode = this.oSession.currentformfeesbatchcode!
        }

        let payload = {
            College_code: this.oSession.collegecode,
            Finyear: this.oSession.finyear,
            Aadhaar: this.oSession.aadhaar,
            batch_code: nBatchcode
        };

        let input_json = {
            Input: encryptUsingAES256(payload),
        };

        this.commonService.Post_json_data<Ires_personalinfo>(Students_url.personalinfo, (input_json)).subscribe((response) => {

            this.ires_personalinfo = response.data
            // console.log(this.ires_personalinfo);

            this.studentDetailsForm.patchValue(this.ires_personalinfo);
        })


    }
    protected readonly console = console;
}